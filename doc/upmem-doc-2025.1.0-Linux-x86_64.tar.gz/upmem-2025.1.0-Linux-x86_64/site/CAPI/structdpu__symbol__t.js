var structdpu__symbol__t =
[
    [ "address", "structdpu__symbol__t.html#abb61977123cad2b2f9491af29b3015f8", null ],
    [ "size", "structdpu__symbol__t.html#a0b15204f53940c9fd42ee5b23b52f7d1", null ]
];