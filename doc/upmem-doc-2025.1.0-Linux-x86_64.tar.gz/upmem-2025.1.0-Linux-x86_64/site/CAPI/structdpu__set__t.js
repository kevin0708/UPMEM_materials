var structdpu__set__t =
[
    [ "dpu", "structdpu__set__t.html#a99bfe1cefdde85ed6e56d8916e6bc3d4", null ],
    [ "kind", "structdpu__set__t.html#ac02e6fb1c03b912b6120be13e8236f7d", null ],
    [ "list", "structdpu__set__t.html#a10ffd49b70d26f910699dcbe9e44951f", null ],
    [ "nr_ranks", "structdpu__set__t.html#a9b3beabc488cdd1cf49cbe39d49d2de2", null ],
    [ "ranks", "structdpu__set__t.html#a7984966424c5fc63343cc446b0593cb4", null ]
];