var dpu__checkpoint_8h =
[
    [ "DPU_CHECKPOINT_ALL", "dpu__checkpoint_8h.html#a7e2a63c68a97950ee12c05deb598f929", null ],
    [ "dpu_checkpoint_flags_t", "dpu__checkpoint_8h.html#abb9439ee0dab8b15dc375d589d7bcb2d", null ],
    [ "_dpu_checkpoint_flags_t", "dpu__checkpoint_8h.html#a37ff07575a54d5dc0f4d3fb9974ae209", [
      [ "DPU_CHECKPOINT_NONE", "dpu__checkpoint_8h.html#a37ff07575a54d5dc0f4d3fb9974ae209a5ea731fb37428edcdea7780c79a88cb0", null ],
      [ "DPU_CHECKPOINT_INTERNAL", "dpu__checkpoint_8h.html#a37ff07575a54d5dc0f4d3fb9974ae209a6bf115d138c3b1945e664906c038ce08", null ],
      [ "DPU_CHECKPOINT_IRAM", "dpu__checkpoint_8h.html#a37ff07575a54d5dc0f4d3fb9974ae209a03f8ad4b2bed3bc6d42290268fb69735", null ],
      [ "DPU_CHECKPOINT_MRAM", "dpu__checkpoint_8h.html#a37ff07575a54d5dc0f4d3fb9974ae209a8cceae9689d06cfb4cf4297de272eb7a", null ],
      [ "DPU_CHECKPOINT_WRAM", "dpu__checkpoint_8h.html#a37ff07575a54d5dc0f4d3fb9974ae209ab2e132e34bf63d3aa052d6243cef977b", null ]
    ] ],
    [ "dpu_checkpoint_deserialize", "dpu__checkpoint_8h.html#a84f6463663d1aeea5a2423832be0a9a9", null ],
    [ "dpu_checkpoint_free", "dpu__checkpoint_8h.html#ac664a279dfdad5f743f4eea0c3abd516", null ],
    [ "dpu_checkpoint_get_serialized_context_size", "dpu__checkpoint_8h.html#a53a1b0a05c5fdc455590fd4294eea38d", null ],
    [ "dpu_checkpoint_restore", "dpu__checkpoint_8h.html#a8e8b95b015cd7950bbbce243a800fbf6", null ],
    [ "dpu_checkpoint_save", "dpu__checkpoint_8h.html#aedeb72b4b6a0b5ab6dffd6ab082eaf64", null ],
    [ "dpu_checkpoint_serialize", "dpu__checkpoint_8h.html#a1ce8758fcf594aa92f60dc34038d328a", null ]
];