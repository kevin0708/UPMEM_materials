var annotated_dup =
[
    [ "dpu_bit_config", "structdpu__bit__config.html", "structdpu__bit__config" ],
    [ "dpu_carousel_config", "structdpu__carousel__config.html", "structdpu__carousel__config" ],
    [ "dpu_context_t", "structdpu__context__t.html", "structdpu__context__t" ],
    [ "dpu_incbin_t", "structdpu__incbin__t.html", "structdpu__incbin__t" ],
    [ "dpu_repair_config", "structdpu__repair__config.html", "structdpu__repair__config" ],
    [ "dpu_set_t", "structdpu__set__t.html", "structdpu__set__t" ],
    [ "dpu_slice_target", "structdpu__slice__target.html", "structdpu__slice__target" ],
    [ "dpu_symbol_t", "structdpu__symbol__t.html", "structdpu__symbol__t" ],
    [ "get_block_t", "structget__block__t.html", "structget__block__t" ],
    [ "sg_block_info", "structsg__block__info.html", "structsg__block__info" ],
    [ "sg_xfer_buffer", "structsg__xfer__buffer.html", "structsg__xfer__buffer" ]
];