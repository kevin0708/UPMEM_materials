var structdpu__repair__config =
[
    [ "A_lsbs", "structdpu__repair__config.html#a70f1f0dab7e4f838d3035ec3107eb807", null ],
    [ "AB_msbs", "structdpu__repair__config.html#ac7f3c8af1089c58cb2b8fc5a497a01c9", null ],
    [ "B_lsbs", "structdpu__repair__config.html#a74ebb5d1638620350a3651a7404504ce", null ],
    [ "C_lsbs", "structdpu__repair__config.html#a25b6c1eff718381ecb8bd3568a2e919f", null ],
    [ "CD_msbs", "structdpu__repair__config.html#a1e50de989821b879a53864bebb545b2e", null ],
    [ "D_lsbs", "structdpu__repair__config.html#a7db670d7326413f5b5f789fe5bc3f4a9", null ],
    [ "even_index", "structdpu__repair__config.html#a94f98e210a01e28458ecd8b15cbcdc08", null ],
    [ "odd_index", "structdpu__repair__config.html#a3c23b188521b24d434ba52bce49ef98f", null ]
];