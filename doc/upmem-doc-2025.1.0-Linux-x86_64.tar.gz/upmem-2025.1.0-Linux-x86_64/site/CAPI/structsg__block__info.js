var structsg__block__info =
[
    [ "addr", "structsg__block__info.html#a7c152ac38eb0c1a7b146a7f575fa4b96", null ],
    [ "length", "structsg__block__info.html#aebb70c2aab3407a9f05334c47131a43b", null ]
];