var dpu__types_8h =
[
    [ "dpu_slice_target", "structdpu__slice__target.html", "structdpu__slice__target" ],
    [ "dpu_set_t", "structdpu__set__t.html", "structdpu__set__t" ],
    [ "dpu_symbol_t", "structdpu__symbol__t.html", "structdpu__symbol__t" ],
    [ "dpu_incbin_t", "structdpu__incbin__t.html", "structdpu__incbin__t" ],
    [ "dpu_bit_config", "structdpu__bit__config.html", "structdpu__bit__config" ],
    [ "dpu_carousel_config", "structdpu__carousel__config.html", "structdpu__carousel__config" ],
    [ "dpu_repair_config", "structdpu__repair__config.html", "structdpu__repair__config" ],
    [ "dpu_context_t", "structdpu__context__t.html", "structdpu__context__t" ],
    [ "sg_xfer_buffer", "structsg__xfer__buffer.html", "structsg__xfer__buffer" ],
    [ "DPU_API_DEPRECATED", "dpu__types_8h.html#aaeef26c699ca110b69f78dd4aa6717c6", null ],
    [ "DPU_BITFIELD_ALL", "dpu__types_8h.html#a1802ebd6decfd9e058aa017513606666", null ],
    [ "DPU_BOOT_THREAD", "dpu__types_8h.html#a90ebf6947adbd03a59432df112051453", null ],
    [ "DPU_MAX_NR_CIS", "dpu__types_8h.html#aeac60f0250bf88b87da1dce43a75a888", null ],
    [ "DPU_MAX_NR_DPUS_PER_CI", "dpu__types_8h.html#a1a673581d1c985d298c0d918c133ec33", null ],
    [ "DPU_MAX_NR_GROUPS", "dpu__types_8h.html#a43ea65c17b34f79edd39c62678defde3", null ],
    [ "DPU_MRAM_HEAP_POINTER_NAME", "dpu__types_8h.html#a8690f6414fc70a8f9a780a59510019de", null ],
    [ "DPU_SLICE_TARGET_TYPE_NAME", "dpu__types_8h.html#ac71e3dd8ae2ce556484d868f536c1be5", null ],
    [ "dpu_bitfield_t", "dpu__types_8h.html#a22c7b79fd8d3a365f8f34ab50d20eb42", null ],
    [ "dpu_ci_bitfield_t", "dpu__types_8h.html#a6e4c6e69751f13d339730264b7d82d58", null ],
    [ "dpu_clock_division_t", "dpu__types_8h.html#ad5caa546e3d765b47573154cb0e4a3a3", null ],
    [ "dpu_event_kind_t", "dpu__types_8h.html#a36c3463f3f82e738572168e8a2a47af5", null ],
    [ "dpu_group_id_t", "dpu__types_8h.html#a6c8a684dede546cf7c0bff59d714d292", null ],
    [ "dpu_id_t", "dpu__types_8h.html#ab1ea8f98e2a9a73e997ec00e7dfecd75", null ],
    [ "dpu_mem_max_addr_t", "dpu__types_8h.html#a450908a1bccbe7b5f4812bf3b4f6a4f2", null ],
    [ "dpu_mem_max_size_t", "dpu__types_8h.html#ad3cfe12f485503d6020725959df39b3e", null ],
    [ "dpu_member_id_t", "dpu__types_8h.html#ab878703e71322d54e25b0935a3cf13b9", null ],
    [ "dpu_notify_bit_id_t", "dpu__types_8h.html#a65462b499253361d7096296b10a0e6b8", null ],
    [ "dpu_rank_id_t", "dpu__types_8h.html#a29fb0fc32c8f99bcb0abd4deea2324d6", null ],
    [ "dpu_set_kind_t", "dpu__types_8h.html#a9e0a9e155613b878093227101e1794d8", null ],
    [ "dpu_slice_id_t", "dpu__types_8h.html#a5b72cda60acea1d2204c5020b5ac8f6a", null ],
    [ "dpu_thread_t", "dpu__types_8h.html#a898047d11597f0a1eb29c43537e31d15", null ],
    [ "dpu_transfer_matrix_type_t", "dpu__types_8h.html#ab1216938c389388fe05e6d8363044416", null ],
    [ "dpuinstruction_t", "dpu__types_8h.html#a31f5c2a172900e726bf382efcd2ca7d7", null ],
    [ "dpuword_t", "dpu__types_8h.html#aca1c6f201f2b4b8ba6107334ef398434", null ],
    [ "iram_addr_t", "dpu__types_8h.html#a02ac19987de4fb7fa4b05254abe4b8df", null ],
    [ "iram_size_t", "dpu__types_8h.html#a3624ea490a37f9c4e02623dd929372ab", null ],
    [ "mram_addr_t", "dpu__types_8h.html#a2bf880739a9a92116472508e144d9bbe", null ],
    [ "mram_size_t", "dpu__types_8h.html#a75d967678a12844109ca56d78541278a", null ],
    [ "wram_addr_t", "dpu__types_8h.html#abfe28927aef6b7fdaae16c105d7ca555", null ],
    [ "wram_size_t", "dpu__types_8h.html#aa5eee74ed970f774dedd597584077278", null ],
    [ "_dpu_clock_division_t", "dpu__types_8h.html#a45c31e421d25727fb4d4a8ff9fd87c16", [
      [ "DPU_CLOCK_DIV8", "dpu__types_8h.html#a45c31e421d25727fb4d4a8ff9fd87c16ad68a4302516bb1845670b70dda72842a", null ],
      [ "DPU_CLOCK_DIV4", "dpu__types_8h.html#a45c31e421d25727fb4d4a8ff9fd87c16a6c85b44f11e122835db1f8d6f6052baa", null ],
      [ "DPU_CLOCK_DIV3", "dpu__types_8h.html#a45c31e421d25727fb4d4a8ff9fd87c16a01edaa3fe9488ff5c75f2c388dd6e29e", null ],
      [ "DPU_CLOCK_DIV2", "dpu__types_8h.html#a45c31e421d25727fb4d4a8ff9fd87c16a4f8a83ab3c9a71e7ca1a579a6d2ef002", null ]
    ] ],
    [ "_dpu_event_kind_t", "dpu__types_8h.html#ae409d7e270659ff1521b6facccc09570", [
      [ "DPU_EVENT_RESET", "dpu__types_8h.html#ae409d7e270659ff1521b6facccc09570a553d0f04452d5f74974eb037de703a78", null ],
      [ "DPU_EVENT_EXTRACT_CONTEXT", "dpu__types_8h.html#ae409d7e270659ff1521b6facccc09570a8f82cb3da5da07ea55204ee3cfd5ee36", null ],
      [ "DPU_EVENT_RESTORE_CONTEXT", "dpu__types_8h.html#ae409d7e270659ff1521b6facccc09570a7e27857fb40c0109597b447081477b03", null ],
      [ "DPU_EVENT_MRAM_ACCESS_PROGRAM", "dpu__types_8h.html#ae409d7e270659ff1521b6facccc09570a04f705907c2bdf00b9302ec865c3c320", null ],
      [ "DPU_EVENT_LOAD_PROGRAM", "dpu__types_8h.html#ae409d7e270659ff1521b6facccc09570aee4cc65634c201288d63386cbbbcc120", null ],
      [ "DPU_EVENT_DEBUG_ACTION", "dpu__types_8h.html#ae409d7e270659ff1521b6facccc09570a6a6b8ff80902392d6c2adbe4bf98f575", null ]
    ] ],
    [ "_dpu_set_kind_t", "dpu__types_8h.html#a10068aec93e59fab5c8e7bd1ccbdf3fb", [
      [ "DPU_SET_RANKS", "dpu__types_8h.html#a10068aec93e59fab5c8e7bd1ccbdf3fba9b74b737917d1843473b6a6c02725811", null ],
      [ "DPU_SET_DPU", "dpu__types_8h.html#a10068aec93e59fab5c8e7bd1ccbdf3fba7cac39dc30a168200bfee864b4f5a47d", null ]
    ] ],
    [ "dpu_pc_mode", "dpu__types_8h.html#acfee532420358201c2f008061e5cb9d2", [
      [ "DPU_PC_MODE_12", "dpu__types_8h.html#acfee532420358201c2f008061e5cb9d2a42b955d0793a1fd269bbdbbf8be0e827", null ],
      [ "DPU_PC_MODE_13", "dpu__types_8h.html#acfee532420358201c2f008061e5cb9d2a9c419200fc1df40cd381f13d1b4455f9", null ],
      [ "DPU_PC_MODE_14", "dpu__types_8h.html#acfee532420358201c2f008061e5cb9d2a91169ff695bab3884aedfc8e8cc8ec68", null ],
      [ "DPU_PC_MODE_15", "dpu__types_8h.html#acfee532420358201c2f008061e5cb9d2a367bad5ac3c7bd2a8955a21ad161066e", null ],
      [ "DPU_PC_MODE_16", "dpu__types_8h.html#acfee532420358201c2f008061e5cb9d2a60d045b4ea07c4a9d8ee7c2c0a1302a1", null ]
    ] ],
    [ "dpu_slice_target_type", "dpu__types_8h.html#a8c20883aaaaadc6a0b83cb4b04114cc8", [
      [ "DPU_SLICE_TARGET_NONE", "dpu__types_8h.html#a8c20883aaaaadc6a0b83cb4b04114cc8a0540dfc0ab3c5a358de76136cf57bebc", null ],
      [ "DPU_SLICE_TARGET_DPU", "dpu__types_8h.html#a8c20883aaaaadc6a0b83cb4b04114cc8a64d553c97b8c07f557fb0689bb7677c1", null ],
      [ "DPU_SLICE_TARGET_ALL", "dpu__types_8h.html#a8c20883aaaaadc6a0b83cb4b04114cc8a20d9134603cd355f6b86b8606ad68953", null ],
      [ "DPU_SLICE_TARGET_GROUP", "dpu__types_8h.html#a8c20883aaaaadc6a0b83cb4b04114cc8aff936ff77f3cc308f6b70c0d2e0884ff", null ],
      [ "NR_OF_DPU_SLICE_TARGETS", "dpu__types_8h.html#a8c20883aaaaadc6a0b83cb4b04114cc8ad887f947275fb98d1f4d7b8ffdb6b490", null ]
    ] ],
    [ "dpu_temperature", "dpu__types_8h.html#af0e67bd8ca1c597cf3cd03c1968b7689", [
      [ "DPU_TEMPERATURE_LESS_THAN_50", "dpu__types_8h.html#af0e67bd8ca1c597cf3cd03c1968b7689af70ce267cbf501c65eb10f0bd13601d2", null ],
      [ "DPU_TEMPERATURE_BETWEEN_50_AND_60", "dpu__types_8h.html#af0e67bd8ca1c597cf3cd03c1968b7689ae0f35ebfcc2ec3ae94112c1bcdf289ae", null ],
      [ "DPU_TEMPERATURE_BETWEEN_60_AND_70", "dpu__types_8h.html#af0e67bd8ca1c597cf3cd03c1968b7689ab56767a3c980f8f487b6f0b872614154", null ],
      [ "DPU_TEMPERATURE_BETWEEN_70_AND_80", "dpu__types_8h.html#af0e67bd8ca1c597cf3cd03c1968b7689ab20ece9c444fe67f88851f5e57716fea", null ],
      [ "DPU_TEMPERATURE_BETWEEN_80_AND_90", "dpu__types_8h.html#af0e67bd8ca1c597cf3cd03c1968b7689a901536be9705f01afe89181a98777dee", null ],
      [ "DPU_TEMPERATURE_BETWEEN_90_AND_100", "dpu__types_8h.html#af0e67bd8ca1c597cf3cd03c1968b7689a370b544f68e88741c760217ddf9eabc7", null ],
      [ "DPU_TEMPERATURE_BETWEEN_100_AND_110", "dpu__types_8h.html#af0e67bd8ca1c597cf3cd03c1968b7689a6eb6953c6c3e58c471b0a6aab53abd65", null ],
      [ "DPU_TEMPERATURE_GREATER_THAN_110", "dpu__types_8h.html#af0e67bd8ca1c597cf3cd03c1968b7689aa43b46837d6c08b816fbebd0d875da9b", null ]
    ] ],
    [ "dpu_transfer_matrix_type_t", "dpu__types_8h.html#a24041773126187ad1a12edff2de7521b", [
      [ "DPU_DEFAULT_XFER_MATRIX", "dpu__types_8h.html#a24041773126187ad1a12edff2de7521ba71ff8eb74350c34bf0b682ba2e22be3d", null ],
      [ "DPU_SG_XFER_MATRIX", "dpu__types_8h.html#a24041773126187ad1a12edff2de7521ba6d214ba87856ed12699d78a5378a0537", null ]
    ] ],
    [ "dpu_slice_target_names", "dpu__types_8h.html#a77d92c2f5675131ad30117271c010f9b", null ]
];