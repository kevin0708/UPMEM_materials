var structdpu__slice__target =
[
    [ "dpu_id", "structdpu__slice__target.html#a0aafd3fa96b923a747f01e5f72b21d1d", null ],
    [ "group_id", "structdpu__slice__target.html#adfb4aac58c2b4d6f65eb191d4cce732a", null ],
    [ "type", "structdpu__slice__target.html#a375f1ddc1c26b5997fdad4a2c8dba48b", null ]
];