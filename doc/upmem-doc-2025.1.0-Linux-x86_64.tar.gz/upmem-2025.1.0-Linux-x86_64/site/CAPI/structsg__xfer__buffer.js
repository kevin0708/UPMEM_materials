var structsg__xfer__buffer =
[
    [ "blocks_addr", "structsg__xfer__buffer.html#a9a37931472b02d77c6f1ba526218c3c7", null ],
    [ "blocks_length", "structsg__xfer__buffer.html#ae811da711a0f606024dee718d347b59c", null ],
    [ "max_nr_blocks", "structsg__xfer__buffer.html#aabe6bff076d1d38bc60b1f712cb37268", null ],
    [ "nr_blocks", "structsg__xfer__buffer.html#a89175d53e57962d3a24ea07c3432d5ed", null ]
];