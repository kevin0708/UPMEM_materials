var structdpu__carousel__config =
[
    [ "cmd_duration", "structdpu__carousel__config.html#a7d83d6dbb2472d92f1b388629e0b559a", null ],
    [ "cmd_sampling", "structdpu__carousel__config.html#a674b405dd639c52ee860aebde429448f", null ],
    [ "res_duration", "structdpu__carousel__config.html#a5d28e44b70e6fb8c11474b6f9466662e", null ],
    [ "res_sampling", "structdpu__carousel__config.html#ae97363927dd35e6e319937c084f9b4d8", null ]
];