var structdpu__bit__config =
[
    [ "cpu2dpu", "structdpu__bit__config.html#a62e17721dcd7f369ba546f57b0f2021c", null ],
    [ "dpu2cpu", "structdpu__bit__config.html#a595bb154c70527238585e106713a6e97", null ],
    [ "nibble_swap", "structdpu__bit__config.html#a6a6ac66fc8ed929aa5ccfd6b0750bdb0", null ],
    [ "stutter", "structdpu__bit__config.html#ac4338c9d8fcf8ec145f2d56aaf89b316", null ]
];