var searchData=
[
  ['type',['type',['../structdpu__slice__target.html#a375f1ddc1c26b5997fdad4a2c8dba48b',1,'dpu_slice_target']]]
];
