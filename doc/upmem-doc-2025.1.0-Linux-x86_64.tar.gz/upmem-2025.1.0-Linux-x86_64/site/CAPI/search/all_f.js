var searchData=
[
  ['ranks',['ranks',['../structdpu__set__t.html#a7984966424c5fc63343cc446b0593cb4',1,'dpu_set_t']]],
  ['registers',['registers',['../structdpu__context__t.html#a247f52293121e24c4b5d60835abdfaf9',1,'dpu_context_t']]],
  ['res_5fduration',['res_duration',['../structdpu__carousel__config.html#a5d28e44b70e6fb8c11474b6f9466662e',1,'dpu_carousel_config']]],
  ['res_5fsampling',['res_sampling',['../structdpu__carousel__config.html#ae97363927dd35e6e319937c084f9b4d8',1,'dpu_carousel_config']]]
];
