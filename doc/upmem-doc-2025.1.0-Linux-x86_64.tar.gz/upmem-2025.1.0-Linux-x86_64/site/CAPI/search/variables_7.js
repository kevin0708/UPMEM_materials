var searchData=
[
  ['info',['info',['../structdpu__context__t.html#ab002ed3e55e2e1e6aa28f4e8c425118d',1,'dpu_context_t']]],
  ['iram',['iram',['../structdpu__context__t.html#a1eb50ac6625bfbb12fc96c8cbeb99a21',1,'dpu_context_t']]],
  ['iram_5fsize',['iram_size',['../structdpu__context__t.html#aa5581ac8e4a7c879cbc04366d9779342',1,'dpu_context_t']]]
];
