var searchData=
[
  ['group_5fid',['group_id',['../structdpu__slice__target.html#adfb4aac58c2b4d6f65eb191d4cce732a',1,'dpu_slice_target']]]
];
