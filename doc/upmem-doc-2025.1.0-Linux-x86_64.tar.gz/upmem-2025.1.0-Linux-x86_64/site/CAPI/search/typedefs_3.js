var searchData=
[
  ['mram_5faddr_5ft',['mram_addr_t',['../dpu__types_8h.html#a2bf880739a9a92116472508e144d9bbe',1,'dpu_types.h']]],
  ['mram_5fsize_5ft',['mram_size_t',['../dpu__types_8h.html#a75d967678a12844109ca56d78541278a',1,'dpu_types.h']]]
];
