var searchData=
[
  ['max_5fnr_5fblocks',['max_nr_blocks',['../structsg__xfer__buffer.html#aabe6bff076d1d38bc60b1f712cb37268',1,'sg_xfer_buffer']]],
  ['mem_5ffault',['mem_fault',['../structdpu__context__t.html#a63fcb6ee6ba4705d1dbfb6d9d9959f52',1,'dpu_context_t']]],
  ['mem_5ffault_5fthread_5findex',['mem_fault_thread_index',['../structdpu__context__t.html#a2bbd7be0238b6ceb970b6aa90a26d03e',1,'dpu_context_t']]],
  ['mram',['mram',['../structdpu__context__t.html#a37cd4f4f7c92e7b0610ca7c477b9b242',1,'dpu_context_t']]],
  ['mram_5faddr_5ft',['mram_addr_t',['../dpu__types_8h.html#a2bf880739a9a92116472508e144d9bbe',1,'dpu_types.h']]],
  ['mram_5fsize',['mram_size',['../structdpu__context__t.html#a65210ebadf74edf3e62b29c0245fac3c',1,'dpu_context_t']]],
  ['mram_5fsize_5ft',['mram_size_t',['../dpu__types_8h.html#a75d967678a12844109ca56d78541278a',1,'dpu_types.h']]]
];
