var searchData=
[
  ['kind',['kind',['../structdpu__set__t.html#ac02e6fb1c03b912b6120be13e8236f7d',1,'dpu_set_t']]]
];
