var searchData=
[
  ['scheduling',['scheduling',['../structdpu__context__t.html#a70368ffc358995e6e8cec5d362d336bf',1,'dpu_context_t']]],
  ['sg_5fblock_5finfo',['sg_block_info',['../structsg__block__info.html',1,'']]],
  ['sg_5fxfer_5fbuffer',['sg_xfer_buffer',['../structsg__xfer__buffer.html',1,'']]],
  ['size',['size',['../structdpu__symbol__t.html#a0b15204f53940c9fd42ee5b23b52f7d1',1,'dpu_symbol_t::size()'],['../structdpu__incbin__t.html#a854352f53b148adc24983a58a1866d66',1,'dpu_incbin_t::size()']]],
  ['stutter',['stutter',['../structdpu__bit__config.html#ac4338c9d8fcf8ec145f2d56aaf89b316',1,'dpu_bit_config']]]
];
