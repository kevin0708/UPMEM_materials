var searchData=
[
  ['wram_5faddr_5ft',['wram_addr_t',['../dpu__types_8h.html#abfe28927aef6b7fdaae16c105d7ca555',1,'dpu_types.h']]],
  ['wram_5fsize_5ft',['wram_size_t',['../dpu__types_8h.html#aa5eee74ed970f774dedd597584077278',1,'dpu_types.h']]]
];
