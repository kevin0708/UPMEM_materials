var searchData=
[
  ['sg_5fblock_5finfo',['sg_block_info',['../structsg__block__info.html',1,'']]],
  ['sg_5fxfer_5fbuffer',['sg_xfer_buffer',['../structsg__xfer__buffer.html',1,'']]]
];
