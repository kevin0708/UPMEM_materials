var searchData=
[
  ['nibble_5fswap',['nibble_swap',['../structdpu__bit__config.html#a6a6ac66fc8ed929aa5ccfd6b0750bdb0',1,'dpu_bit_config']]],
  ['nr_5fatomic_5fbits',['nr_atomic_bits',['../structdpu__context__t.html#a289b96e6a770f7522e42d880f4933c47',1,'dpu_context_t']]],
  ['nr_5fblocks',['nr_blocks',['../structsg__xfer__buffer.html#a89175d53e57962d3a24ea07c3432d5ed',1,'sg_xfer_buffer']]],
  ['nr_5fof_5frunning_5fthreads',['nr_of_running_threads',['../structdpu__context__t.html#a4a2cf74e4cd0fad28f6af986421d6148',1,'dpu_context_t']]],
  ['nr_5franks',['nr_ranks',['../structdpu__set__t.html#a9b3beabc488cdd1cf49cbe39d49d2de2',1,'dpu_set_t']]],
  ['nr_5fregisters',['nr_registers',['../structdpu__context__t.html#aa6cd9be0e5abf73710f486d28db56fab',1,'dpu_context_t']]],
  ['nr_5fthreads',['nr_threads',['../structdpu__context__t.html#a4bee515a7e030c8b0dac1cf0ce34a2a2',1,'dpu_context_t']]]
];
