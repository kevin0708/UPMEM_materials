var searchData=
[
  ['get_5fblock_5ffunc_5ft',['get_block_func_t',['../dpu_8h.html#aaabcb7de10204c70a2c221dbc20189f1',1,'dpu.h']]],
  ['get_5fblock_5ft',['get_block_t',['../structget__block__t.html',1,'get_block_t'],['../dpu_8h.html#afbfa2875ca5f27c3011eddaccc12141f',1,'get_block_t():&#160;dpu.h']]],
  ['group_5fid',['group_id',['../structdpu__slice__target.html#adfb4aac58c2b4d6f65eb191d4cce732a',1,'dpu_slice_target']]]
];
