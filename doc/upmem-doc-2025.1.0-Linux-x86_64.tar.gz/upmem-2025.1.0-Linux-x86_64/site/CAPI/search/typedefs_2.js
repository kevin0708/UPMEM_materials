var searchData=
[
  ['iram_5faddr_5ft',['iram_addr_t',['../dpu__types_8h.html#a02ac19987de4fb7fa4b05254abe4b8df',1,'dpu_types.h']]],
  ['iram_5fsize_5ft',['iram_size_t',['../dpu__types_8h.html#a3624ea490a37f9c4e02623dd929372ab',1,'dpu_types.h']]]
];
