var searchData=
[
  ['wram',['wram',['../structdpu__context__t.html#a4dba948d6b47d0e2b4263d0e3883e91b',1,'dpu_context_t']]],
  ['wram_5faddr_5ft',['wram_addr_t',['../dpu__types_8h.html#abfe28927aef6b7fdaae16c105d7ca555',1,'dpu_types.h']]],
  ['wram_5fsize',['wram_size',['../structdpu__context__t.html#a8c2b1c24d1b496c683a277bed3741a4b',1,'dpu_context_t']]],
  ['wram_5fsize_5ft',['wram_size_t',['../dpu__types_8h.html#aa5eee74ed970f774dedd597584077278',1,'dpu_types.h']]]
];
