var structdpu__incbin__t =
[
    [ "buffer", "structdpu__incbin__t.html#a56ed84df35de10bdb65e72b184309497", null ],
    [ "path", "structdpu__incbin__t.html#a3b02c6de5c049804444a246f7fdf46b4", null ],
    [ "size", "structdpu__incbin__t.html#a854352f53b148adc24983a58a1866d66", null ]
];