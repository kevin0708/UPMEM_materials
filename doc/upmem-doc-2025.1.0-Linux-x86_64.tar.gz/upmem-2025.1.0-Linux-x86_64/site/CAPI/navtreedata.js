var NAVTREE =
[
  [ "DPU Host API", "index.html", [
    [ "Overview", "index.html#Overview", null ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Globals", "globals.html", [
      [ "All", "globals.html", null ],
      [ "Functions", "globals_func.html", null ],
      [ "Typedefs", "globals_type.html", null ],
      [ "Enumerations", "globals_enum.html", null ],
      [ "Enumerator", "globals_eval.html", null ],
      [ "Macros", "globals_defs.html", null ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"structdpu__context__t.html#a70368ffc358995e6e8cec5d362d336bf"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';