var structget__block__t =
[
    [ "args", "structget__block__t.html#add0eb34e0cef9e763462cf9080f9be0a", null ],
    [ "args_size", "structget__block__t.html#aa7ce86a768e2fe84f33a9efc4e70c9ff", null ],
    [ "f", "structget__block__t.html#ad26e1e05fdf1d2f2033bc50107bf4d8a", null ]
];