var structdpu__vpd__string__pair =
[
    [ "key", "structdpu__vpd__string__pair.html#a302e2291dbff57f770bf469af498ec3a", null ],
    [ "next", "structdpu__vpd__string__pair.html#aff013ef13865e1d1c796a3dc19177a63", null ],
    [ "value", "structdpu__vpd__string__pair.html#a952181be57dba7891e7b2da65a061e25", null ],
    [ "value_len", "structdpu__vpd__string__pair.html#a2f4ca32f475d4554a45911e5924c4214", null ],
    [ "value_type", "structdpu__vpd__string__pair.html#a8e5437c854cb675df55bdcb5aaada2e0", null ]
];