var struct__dpu__description__t =
[
    [ "_internals", "struct__dpu__description__t.html#aaa582b06a86f5f9679222b9a59a1d750", null ],
    [ "api_must_switch_mram_mux", "struct__dpu__description__t.html#a70b71dc5eb16f118be6f80ef6979daad", null ],
    [ "configuration", "struct__dpu__description__t.html#a1d6b68ca5dbceb04f269faea2411b552", null ],
    [ "data", "struct__dpu__description__t.html#a735984d41155bc1032e09bece8f8d66d", null ],
    [ "disable_api_safe_checks", "struct__dpu__description__t.html#ad76d241e6cfd62a52573600658cbdb87", null ],
    [ "disable_reset_on_alloc", "struct__dpu__description__t.html#a67af82c1bbf2c9b54768377653bdc403", null ],
    [ "do_iram_repair", "struct__dpu__description__t.html#a6e1cbbcab37d9f04479428be0ef7e0f7", null ],
    [ "do_wram_repair", "struct__dpu__description__t.html#a98bc8d19cb2802f71dfa1aea75cf4d0d", null ],
    [ "enable_cycle_accurate_behavior", "struct__dpu__description__t.html#a73ae534b56d32ee3c74f254f8d8341e0", null ],
    [ "free", "struct__dpu__description__t.html#a747ee931fd8666f6712d0031f31cd9b0", null ],
    [ "hw", "struct__dpu__description__t.html#a03ef027fd9faf40bfdf4e8aa03a47804", null ],
    [ "ignore_vpd", "struct__dpu__description__t.html#a6b59d2fe956f88501177ef1c362922c0", null ],
    [ "ila_control_refresh", "struct__dpu__description__t.html#a165e19c84138b70dc95c84dbf8a95417", null ],
    [ "init_mram_mux", "struct__dpu__description__t.html#ac4c605658298ef5c716306ef173641e7", null ],
    [ "mram_access_by_dpu_only", "struct__dpu__description__t.html#acf40c52c2193419782087659da404391", null ],
    [ "refcount", "struct__dpu__description__t.html#ab35ea39209f22551504767050541e8ed", null ],
    [ "type", "struct__dpu__description__t.html#a0cc9dbfa4e34ec2df31b8a1e9909cb57", null ]
];