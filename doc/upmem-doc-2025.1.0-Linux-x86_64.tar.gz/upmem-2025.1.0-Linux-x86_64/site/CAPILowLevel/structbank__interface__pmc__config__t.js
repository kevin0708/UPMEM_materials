var structbank__interface__pmc__config__t =
[
    [ "counter_1", "structbank__interface__pmc__config__t.html#a5d7966550e48a728787b4900122e57d5", null ],
    [ "counter_2", "structbank__interface__pmc__config__t.html#a6c30475518b545fe27ffa436e8e66050", null ],
    [ "mode", "structbank__interface__pmc__config__t.html#ad141474bf72bd52c93a0af1f1d643a63", null ]
];