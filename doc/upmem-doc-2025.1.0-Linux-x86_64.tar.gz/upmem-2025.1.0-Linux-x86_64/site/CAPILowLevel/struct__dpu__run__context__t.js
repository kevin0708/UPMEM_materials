var struct__dpu__run__context__t =
[
    [ "dpu_in_fault", "struct__dpu__run__context__t.html#a52b3f989f82b64dab47811c152ae81e3", null ],
    [ "dpu_running", "struct__dpu__run__context__t.html#ac1f2cd9f84a7b1a17464ba41986efa1c", null ],
    [ "nb_dpu_running", "struct__dpu__run__context__t.html#a644e79cd71c07df0272b8d5e9fd5161d", null ],
    [ "poll_status", "struct__dpu__run__context__t.html#a0ae0171009fdaeae7a543ff0f86908c5", null ]
];