var structdpu__elf__symbols =
[
    [ "map", "structdpu__elf__symbols.html#ad06710f14219575ba704e370b28a5945", null ],
    [ "nr_symbols", "structdpu__elf__symbols.html#aaece2664c56217cb0db2081b82a83256", null ]
];