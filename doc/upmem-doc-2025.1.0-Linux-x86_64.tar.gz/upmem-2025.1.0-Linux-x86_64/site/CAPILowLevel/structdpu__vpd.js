var structdpu__vpd =
[
    [ "repair_entries", "structdpu__vpd.html#a5a51985f46ff5c95a3d84d58fc273ff4", null ],
    [ "vpd_header", "structdpu__vpd.html#a399b1efb3881f03630423402c5cecd1a", null ]
];