var structdpu__fifo__rank__t =
[
    [ "dpu_fifo_address", "structdpu__fifo__rank__t.html#afd777fb4f5e73c32a7b6b4f9bbcd389c", null ],
    [ "dpu_fifo_data_size", "structdpu__fifo__rank__t.html#a622cd9f20b4b54de8e7b80a3f73e10fa", null ],
    [ "dpu_fifo_pointers", "structdpu__fifo__rank__t.html#a7de06661c3dcd5de973023f4185239ee", null ],
    [ "dpu_fifo_ptr_size", "structdpu__fifo__rank__t.html#af52ad9605bd2df9ac91197ec329808ea", null ],
    [ "fifo_pointers_matrix", "structdpu__fifo__rank__t.html#adfede415f9ec5b72757f3c9396101165", null ],
    [ "max_retries", "structdpu__fifo__rank__t.html#ad9f2e1ffd3c3f4692cebbc3c0975db7d", null ],
    [ "time_for_retry", "structdpu__fifo__rank__t.html#ae4a4d8b3e3b8fabb8e5217a769a84459", null ],
    [ "transfer_matrix", "structdpu__fifo__rank__t.html#aaebdc9a0953047894c97c5c00d800b49", null ]
];