var struct__dpu__elf__runtime__info__item =
[
    [ "exists", "struct__dpu__elf__runtime__info__item.html#a6e480061dc5ecc1f85a71989a6352dfc", null ],
    [ "size", "struct__dpu__elf__runtime__info__item.html#ab2c6b258f02add8fdf4cfc7c371dd772", null ],
    [ "value", "struct__dpu__elf__runtime__info__item.html#ae7f66047e6e39ba2bb6af8b95f00d1dd", null ]
];