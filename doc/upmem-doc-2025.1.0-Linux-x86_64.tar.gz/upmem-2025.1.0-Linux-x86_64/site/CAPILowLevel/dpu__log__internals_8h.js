var dpu__log__internals_8h =
[
    [ "DPU_LOG_FORMAT_HEADER", "dpu__log__internals_8h.html#ab403ad302fb09c09aa09d448d7e700c1", null ],
    [ "dpu_log_print_fct_t", "dpu__log__internals_8h.html#a32f1efdab8675645b04bb7732bcee101", null ],
    [ "dpulog_c_print_fct", "dpu__log__internals_8h.html#a63c22a0a0e0ae8347ccf85e786377dce", null ],
    [ "dpulog_read_and_display_contents_of", "dpu__log__internals_8h.html#a2061d433e8e64dd9b3f2f709272f1ac7", null ],
    [ "dpulog_read_for_dpu_", "dpu__log__internals_8h.html#a131e4019ae43bfb586ae0c485a60d501", null ]
];