var dpu__description_8h =
[
    [ "_dpu_description_t", "struct__dpu__description__t.html", "struct__dpu__description__t" ],
    [ "dpu_description_t", "dpu__description_8h.html#a2bec79181f9b0c58960b608fa2ccf5f9", null ],
    [ "dpu_acquire_description", "dpu__description_8h.html#afcfdb20d4bc40d7711c8256a684d5858", null ],
    [ "dpu_free_description", "dpu__description_8h.html#a2bae94735543e48961b511e864488d18", null ]
];