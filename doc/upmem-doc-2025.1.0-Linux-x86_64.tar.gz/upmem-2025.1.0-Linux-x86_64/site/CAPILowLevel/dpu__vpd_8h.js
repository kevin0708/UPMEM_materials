var dpu__vpd_8h =
[
    [ "dpu_vpd_add_repair_entry", "dpu__vpd_8h.html#a7a204b8fd6d3ba290db9922e809002b9", null ],
    [ "dpu_vpd_commit_to_device", "dpu__vpd_8h.html#a0deab7aaa43aeba14c008770d972eb71", null ],
    [ "dpu_vpd_commit_to_device_from_file", "dpu__vpd_8h.html#a51396c98e072e47874fb449f45852926", null ],
    [ "dpu_vpd_db_commit_to_device", "dpu__vpd_8h.html#a0fcf8dbf36a67f070da0ccc4153ac6c1", null ],
    [ "dpu_vpd_db_commit_to_device_from_file", "dpu__vpd_8h.html#a2d7ccb26210ef6d288ddefa9e837c9d2", null ],
    [ "dpu_vpd_db_destroy", "dpu__vpd_8h.html#a7617205251d7462ef497558298470d6d", null ],
    [ "dpu_vpd_db_init", "dpu__vpd_8h.html#aaab87f33f579cfbc7cdea4c8e48ba098", null ],
    [ "dpu_vpd_db_update", "dpu__vpd_8h.html#a3677effa99370bc980ae4ce5e4206856", null ],
    [ "dpu_vpd_db_write", "dpu__vpd_8h.html#ab1a95bb96f15891d0e7ca7e87f1ca5e9", null ],
    [ "dpu_vpd_disable_dpu", "dpu__vpd_8h.html#a386af94e950d9954f499ead08d612f05", null ],
    [ "dpu_vpd_enable_dpu", "dpu__vpd_8h.html#a11addc0f5d082c234a036346aaa32340", null ],
    [ "dpu_vpd_get_pull_vpd_path", "dpu__vpd_8h.html#a17e0656b378326887065685fb7ab25c3", null ],
    [ "dpu_vpd_get_vpd_path", "dpu__vpd_8h.html#a805ff1c6078bf15f277b0154ef1d7010", null ],
    [ "dpu_vpd_init", "dpu__vpd_8h.html#aab90c9b39a8d5974dcd5881de8755c18", null ],
    [ "dpu_vpd_update_from_mcu", "dpu__vpd_8h.html#a12fb6d33aa7498d5636e80f16898086e", null ],
    [ "dpu_vpd_write", "dpu__vpd_8h.html#a07f037cddd26e23269b3676a78460c21", null ]
];