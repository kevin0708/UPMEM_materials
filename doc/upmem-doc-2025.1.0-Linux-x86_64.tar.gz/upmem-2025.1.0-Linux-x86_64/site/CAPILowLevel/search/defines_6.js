var searchData=
[
  ['vpd_5fmax_5frank',['VPD_MAX_RANK',['../dpu__vpd__structures_8h.html#a76bde86586fa074cc66700085b96546b',1,'dpu_vpd_structures.h']]],
  ['vpd_5fmax_5fsize',['VPD_MAX_SIZE',['../dpu__vpd__structures_8h.html#adb543da16553538e91023b95f7f7f8f1',1,'dpu_vpd_structures.h']]],
  ['vpd_5fstruct_5fid',['VPD_STRUCT_ID',['../dpu__vpd__structures_8h.html#ae8821b9f863b8d8961c055462ce6b3ca',1,'dpu_vpd_structures.h']]],
  ['vpd_5fstruct_5fversion',['VPD_STRUCT_VERSION',['../dpu__vpd__structures_8h.html#aa16a2fa4af34c9c9c1e31fe97489621c',1,'dpu_vpd_structures.h']]],
  ['vpd_5fundefined_5frepair_5fcount',['VPD_UNDEFINED_REPAIR_COUNT',['../dpu__vpd__structures_8h.html#a9ebd1bd60b12684d353ad839e04a0b9a',1,'dpu_vpd_structures.h']]]
];
