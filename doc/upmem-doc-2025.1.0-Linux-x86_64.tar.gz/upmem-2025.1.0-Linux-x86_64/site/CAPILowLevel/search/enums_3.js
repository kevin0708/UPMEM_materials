var searchData=
[
  ['vpd_5fdata_5ftype',['vpd_data_type',['../dpu__vpd__structures_8h.html#a6ea39ade67644ebf7cddbe865e2540e9',1,'dpu_vpd_structures.h']]]
];
