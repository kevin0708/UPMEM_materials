var searchData=
[
  ['ignore_5fvpd',['ignore_vpd',['../struct__dpu__description__t.html#a6b59d2fe956f88501177ef1c362922c0',1,'_dpu_description_t']]],
  ['ila_5fcontrol_5frefresh',['ila_control_refresh',['../struct__dpu__description__t.html#a165e19c84138b70dc95c84dbf8a95417',1,'_dpu_description_t']]],
  ['init_5fmram_5fmux',['init_mram_mux',['../struct__dpu__description__t.html#ac4c605658298ef5c716306ef173641e7',1,'_dpu_description_t']]],
  ['iram_5frepair',['iram_repair',['../structdpu__vpd__rank__data.html#a36a53c86f1522d4906ecc4fb027a0860',1,'dpu_vpd_rank_data']]],
  ['iram_5fsize',['iram_size',['../structdpu__hw__description__t.html#aa5581ac8e4a7c879cbc04366d9779342',1,'dpu_hw_description_t']]],
  ['iram_5fwram',['iram_wram',['../structdpu__vpd__repair__entry.html#ac4bfa5b6b7bef57afa7642aaaa103c0d',1,'dpu_vpd_repair_entry']]]
];
