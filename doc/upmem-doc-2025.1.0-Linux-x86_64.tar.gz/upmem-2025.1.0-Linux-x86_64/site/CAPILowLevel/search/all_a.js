var searchData=
[
  ['map',['map',['../structdpu__elf__symbols.html#ad06710f14219575ba704e370b28a5945',1,'dpu_elf_symbols']]],
  ['max_5fnr_5fdpus_5fper_5frank',['MAX_NR_DPUS_PER_RANK',['../dpu__transfer__matrix_8h.html#a922f398fbb1480797d82f33a5e04a6c3',1,'dpu_transfer_matrix.h']]],
  ['max_5fretries',['max_retries',['../structdpu__fifo__rank__t.html#ad9f2e1ffd3c3f4692cebbc3c0975db7d',1,'dpu_fifo_rank_t']]],
  ['mcount',['mcount',['../struct__dpu__elf__runtime__info.html#ada422cf0ba3ccfd2696c7135cc6e0ae6',1,'_dpu_elf_runtime_info']]],
  ['mcount_5faddress',['mcount_address',['../struct__dpu__profiling__context__t.html#a4fbf6a900a47c47aa37fffd874050f20',1,'_dpu_profiling_context_t::mcount_address()'],['../structdpu__program__t.html#a9805e15d403826afd614fda8a980f230',1,'dpu_program_t::mcount_address()']]],
  ['mcount_5fstats',['mcount_stats',['../struct__dpu__profiling__context__t.html#ad78f3e3820da3eea24148af4f71c3df2',1,'_dpu_profiling_context_t']]],
  ['mem_5fpatch_5ffunction_5ft',['mem_patch_function_t',['../dpu__loader_8h.html#a66d6094c159354f920d7398688f62fdf',1,'dpu_loader.h']]],
  ['memories',['memories',['../structdpu__hw__description__t.html#ab23fbd77817709e73c13ef261df338f5',1,'dpu_hw_description_t']]],
  ['mode',['mode',['../structbank__interface__pmc__config__t.html#ad141474bf72bd52c93a0af1f1d643a63',1,'bank_interface_pmc_config_t']]],
  ['mram_5faccess_5fby_5fdpu_5fonly',['mram_access_by_dpu_only',['../struct__dpu__description__t.html#acf40c52c2193419782087659da404391',1,'_dpu_description_t']]],
  ['mram_5fsize',['mram_size',['../structdpu__hw__description__t.html#a65210ebadf74edf3e62b29c0245fac3c',1,'dpu_hw_description_t']]],
  ['mutex_5finfo',['mutex_info',['../struct__dpu__elf__runtime__info.html#a354ac809f522d68abfaaeee1f34bc386',1,'_dpu_elf_runtime_info']]]
];
