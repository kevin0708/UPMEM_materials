var searchData=
[
  ['mem_5fpatch_5ffunction_5ft',['mem_patch_function_t',['../dpu__loader_8h.html#a66d6094c159354f920d7398688f62fdf',1,'dpu_loader.h']]]
];
