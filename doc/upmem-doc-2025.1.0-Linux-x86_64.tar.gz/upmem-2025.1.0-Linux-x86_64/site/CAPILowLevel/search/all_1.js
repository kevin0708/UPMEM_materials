var searchData=
[
  ['address',['address',['../struct__dpu__profiling__context__t.html#adda4897d6088ea3d1743355b7a1c2c94',1,'_dpu_profiling_context_t::address()'],['../structdpu__vpd__repair__entry.html#a643d30df67a67c5915fde941c934f9f8',1,'dpu_vpd_repair_entry::address()']]],
  ['api_5fmust_5fswitch_5fmram_5fmux',['api_must_switch_mram_mux',['../struct__dpu__description__t.html#a70b71dc5eb16f118be6f80ef6979daad',1,'_dpu_description_t']]]
];
