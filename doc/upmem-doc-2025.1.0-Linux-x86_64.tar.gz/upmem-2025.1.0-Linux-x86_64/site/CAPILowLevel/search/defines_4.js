var searchData=
[
  ['nb_5fmax_5frepair',['NB_MAX_REPAIR',['../dpu__vpd__structures_8h.html#a439fecfe7384f66788413ffb91c08086',1,'dpu_vpd_structures.h']]],
  ['next_5fdpu_5fchip_5fidx',['NEXT_DPU_CHIP_IDX',['../dpu__chip__id_8h.html#a489d0fcc6a10a82ece5ab2051467d4ed',1,'dpu_chip_id.h']]]
];
