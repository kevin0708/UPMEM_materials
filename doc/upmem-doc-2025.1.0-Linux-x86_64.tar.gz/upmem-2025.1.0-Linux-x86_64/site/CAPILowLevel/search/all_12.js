var searchData=
[
  ['wram_5frepair',['wram_repair',['../structdpu__vpd__rank__data.html#a8623b45d220d6701e174aa61c07064ed',1,'dpu_vpd_rank_data']]],
  ['wram_5fsize',['wram_size',['../structdpu__hw__description__t.html#a8c2b1c24d1b496c683a277bed3741a4b',1,'dpu_hw_description_t']]]
];
