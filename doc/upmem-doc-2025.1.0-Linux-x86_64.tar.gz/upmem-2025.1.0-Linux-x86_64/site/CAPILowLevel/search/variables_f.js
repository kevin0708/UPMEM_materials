var searchData=
[
  ['sample_5fstats',['sample_stats',['../struct__dpu__profiling__context__t.html#ad951f2f3f72e8896313cf18f779bd5ef',1,'_dpu_profiling_context_t']]],
  ['semaphore_5finfo',['semaphore_info',['../struct__dpu__elf__runtime__info.html#a71356ee99c61e53f511487d334aa43d0',1,'_dpu_elf_runtime_info']]],
  ['sg_5fptr',['sg_ptr',['../structdpu__transfer__matrix.html#a7f5ff12c65651f9a8d6bf574daca71d5',1,'dpu_transfer_matrix']]],
  ['signature',['signature',['../structdpu__hw__description__t.html#a59753424a8046c32ed80b5e00838d8c7',1,'dpu_hw_description_t']]],
  ['size',['size',['../structdpu__elf__symbol.html#aac913b3a1f6ef005d66bf7a84428773e',1,'dpu_elf_symbol::size()'],['../struct__dpu__elf__runtime__info__item.html#ab2c6b258f02add8fdf4cfc7c371dd772',1,'_dpu_elf_runtime_info_item::size()'],['../structdpu__transfer__matrix.html#ab2c6b258f02add8fdf4cfc7c371dd772',1,'dpu_transfer_matrix::size()']]],
  ['std_5ftemperature',['std_temperature',['../structdpu__hw__description__t.html#afda1624562e690ed198c62a3a6747762',1,'dpu_hw_description_t']]],
  ['struct_5fid',['struct_id',['../structdpu__vpd__header.html#aa5326df180cb23c59afbcab711a06479',1,'dpu_vpd_header']]],
  ['struct_5fsize',['struct_size',['../structdpu__vpd__header.html#a3411425b545585f06b75516b5291a6ac',1,'dpu_vpd_header']]],
  ['struct_5fver',['struct_ver',['../structdpu__vpd__header.html#a2ab8dec45245c61c730298605dde55c1',1,'dpu_vpd_header']]],
  ['symbols',['symbols',['../structdpu__program__t.html#a798ab0bb5a1678db2366c75f2857f3af',1,'dpu_program_t']]],
  ['sys_5fend',['sys_end',['../struct__dpu__elf__runtime__info.html#a39c3b2862d14bd30d9200e185b5717d6',1,'_dpu_elf_runtime_info']]],
  ['sys_5fheap_5fpointer',['sys_heap_pointer',['../struct__dpu__elf__runtime__info.html#a4d0aab9f5b7eb6365663e612785aec3a',1,'_dpu_elf_runtime_info']]],
  ['sys_5fheap_5fpointer_5freset',['sys_heap_pointer_reset',['../struct__dpu__elf__runtime__info.html#ac0cb1cd63bfadd97eb5f0af0d4dc01a2',1,'_dpu_elf_runtime_info']]],
  ['sys_5fstack_5ftable',['sys_stack_table',['../struct__dpu__elf__runtime__info.html#a1eb15942004ead06d5b36b9829891bf8',1,'_dpu_elf_runtime_info']]],
  ['sys_5fwq_5ftable',['sys_wq_table',['../struct__dpu__elf__runtime__info.html#a2dc95e8ed11095aadbac2bbca191d9d1',1,'_dpu_elf_runtime_info']]]
];
