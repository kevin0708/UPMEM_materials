var searchData=
[
  ['max_5fnr_5fdpus_5fper_5frank',['MAX_NR_DPUS_PER_RANK',['../dpu__transfer__matrix_8h.html#a922f398fbb1480797d82f33a5e04a6c3',1,'dpu_transfer_matrix.h']]]
];
