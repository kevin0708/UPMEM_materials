var indexSectionsWithContent =
{
  0: "_abcdefhikmnoprstvw",
  1: "_bd",
  2: "d",
  3: "cdf",
  4: "_abcdefhikmnoprstvw",
  5: "dm",
  6: "_bdv",
  7: "bd",
  8: "_demnsv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros"
};

