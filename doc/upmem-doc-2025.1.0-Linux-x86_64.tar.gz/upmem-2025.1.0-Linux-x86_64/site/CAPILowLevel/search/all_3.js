var searchData=
[
  ['carousel',['carousel',['../structdpu__hw__description__t.html#a3b518bc39e54ceb93ff0efa1b7d4ed23',1,'dpu_hw_description_t']]],
  ['chip_5fid',['chip_id',['../structdpu__hw__description__t.html#a27f5d6cadb40c56ab2d1bf42e551a09b',1,'dpu_hw_description_t']]],
  ['chip_5fid_5fto_5fidx',['chip_id_to_idx',['../dpu__chip__id_8h.html#ad3a2942322767eceab4eb9814f3f7bbb',1,'dpu_chip_id.h']]],
  ['ci',['ci',['../structdpu__vpd__repair__entry.html#a6ae95b90a8247d90fef62b51d9e60e25',1,'dpu_vpd_repair_entry']]],
  ['ci_5fmask',['ci_mask',['../structdpu__hw__description__t.html#a80c84748df64472c8f830dbe38e28300',1,'dpu_hw_description_t']]],
  ['ci_5fpc_5flsb_5fnr_5fphys_5fbits',['ci_pc_lsb_nr_phys_bits',['../structdpu__hw__description__t.html#a01553ed1d6d8b54f24a06d6a17114cb3',1,'dpu_hw_description_t']]],
  ['clock_5fdivision',['clock_division',['../structdpu__hw__description__t.html#ab03a47427cc02fa0e191a0688a078e00',1,'dpu_hw_description_t']]],
  ['close_5fprint_5fsequence',['close_print_sequence',['../struct__dpu__elf__runtime__info.html#a7c7cdce40017ddd41a5f170b0fdf5ecd',1,'_dpu_elf_runtime_info']]],
  ['close_5fprint_5fsequence_5faddr',['close_print_sequence_addr',['../structdpu__program__t.html#a076a80220172c3e7fe04ecd59934b54e',1,'dpu_program_t']]],
  ['configuration',['configuration',['../struct__dpu__description__t.html#a1d6b68ca5dbceb04f269faea2411b552',1,'_dpu_description_t']]],
  ['count',['count',['../struct__dpu__profiling__context__t.html#afcc68e9eec57ce069fcdc37815837d6d',1,'_dpu_profiling_context_t']]],
  ['counter_5f1',['counter_1',['../structbank__interface__pmc__config__t.html#a5d7966550e48a728787b4900122e57d5',1,'bank_interface_pmc_config_t::counter_1()'],['../structbank__interface__pmc__result__t.html#a3b2d26a272c46348bdf53c50c279ff22',1,'bank_interface_pmc_result_t::counter_1()'],['../structbank__interface__pmc__result__t.html#ae5a7ebb52ff37efeba5b41beb831dc6f',1,'bank_interface_pmc_result_t::counter_1()']]],
  ['counter_5f2',['counter_2',['../structbank__interface__pmc__config__t.html#a6c30475518b545fe27ffa436e8e66050',1,'bank_interface_pmc_config_t::counter_2()'],['../structbank__interface__pmc__result__t.html#a0d5905ec17d4fcb273f902dae5c25aac',1,'bank_interface_pmc_result_t::counter_2()']]]
];
