var searchData=
[
  ['data',['data',['../struct__dpu__description__t.html#a735984d41155bc1032e09bece8f8d66d',1,'_dpu_description_t']]],
  ['direction',['direction',['../structdpu__fifo__link__t.html#a9840d712bf5f533cdc05b80a2219631e',1,'dpu_fifo_link_t']]],
  ['disable_5fapi_5fsafe_5fchecks',['disable_api_safe_checks',['../struct__dpu__description__t.html#ad76d241e6cfd62a52573600658cbdb87',1,'_dpu_description_t']]],
  ['disable_5freset_5fon_5falloc',['disable_reset_on_alloc',['../struct__dpu__description__t.html#a67af82c1bbf2c9b54768377653bdc403',1,'_dpu_description_t']]],
  ['do_5firam_5frepair',['do_iram_repair',['../struct__dpu__description__t.html#a6e1cbbcab37d9f04479428be0ef7e0f7',1,'_dpu_description_t']]],
  ['do_5fwram_5frepair',['do_wram_repair',['../struct__dpu__description__t.html#a98bc8d19cb2802f71dfa1aea75cf4d0d',1,'_dpu_description_t']]],
  ['dpu',['dpu',['../structdpu__hw__description__t.html#a45a7d21d2cdbe338b5e204d6c2e9d93f',1,'dpu_hw_description_t::dpu()'],['../struct__dpu__loader__env__t.html#a99bfe1cefdde85ed6e56d8916e6bc3d4',1,'_dpu_loader_env_t::dpu()'],['../struct__dpu__profiling__context__t.html#a99bfe1cefdde85ed6e56d8916e6bc3d4',1,'_dpu_profiling_context_t::dpu()'],['../structdpu__vpd__repair__entry.html#a78ded4b3610cb2c77528b8fffd12efbf',1,'dpu_vpd_repair_entry::dpu()']]],
  ['dpu_5fdisabled',['dpu_disabled',['../structdpu__vpd__rank__data.html#a1e3bc8d47d59b9ff7a25aabcf8d8ab07',1,'dpu_vpd_rank_data']]],
  ['dpu_5ffifo_5faddress',['dpu_fifo_address',['../structdpu__fifo__rank__t.html#afd777fb4f5e73c32a7b6b4f9bbcd389c',1,'dpu_fifo_rank_t']]],
  ['dpu_5ffifo_5fdata_5fsize',['dpu_fifo_data_size',['../structdpu__fifo__rank__t.html#a622cd9f20b4b54de8e7b80a3f73e10fa',1,'dpu_fifo_rank_t']]],
  ['dpu_5ffifo_5fpointers',['dpu_fifo_pointers',['../structdpu__fifo__rank__t.html#a7de06661c3dcd5de973023f4185239ee',1,'dpu_fifo_rank_t']]],
  ['dpu_5ffifo_5fptr_5fsize',['dpu_fifo_ptr_size',['../structdpu__fifo__rank__t.html#af52ad9605bd2df9ac91197ec329808ea',1,'dpu_fifo_rank_t']]],
  ['dpu_5fin_5ffault',['dpu_in_fault',['../struct__dpu__run__context__t.html#a52b3f989f82b64dab47811c152ae81e3',1,'_dpu_run_context_t']]],
  ['dpu_5frunning',['dpu_running',['../struct__dpu__run__context__t.html#ac1f2cd9f84a7b1a17464ba41986efa1c',1,'_dpu_run_context_t']]],
  ['dummy',['dummy',['../struct__dpu__loader__context__t.html#a44b7a3baf02bac7ad707e8f2f5eca1ca',1,'_dpu_loader_context_t']]]
];
