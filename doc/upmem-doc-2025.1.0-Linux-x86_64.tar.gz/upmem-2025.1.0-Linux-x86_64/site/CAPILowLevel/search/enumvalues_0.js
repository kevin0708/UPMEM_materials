var searchData=
[
  ['bank_5finterface_5fpmc_5fcycles',['BANK_INTERFACE_PMC_CYCLES',['../dpu__bank__interface__pmc_8h.html#a8f43397a8671ffef7972f5bcfff7100fa0ff7ceeb48178efbae757d5f96e93a5c',1,'dpu_bank_interface_pmc.h']]],
  ['bank_5finterface_5fpmc_5fhost_5factivate_5fcommand',['BANK_INTERFACE_PMC_HOST_ACTIVATE_COMMAND',['../dpu__bank__interface__pmc_8h.html#a8f43397a8671ffef7972f5bcfff7100fa78379824b82aac7545210246166006fc',1,'dpu_bank_interface_pmc.h']]],
  ['bank_5finterface_5fpmc_5fhost_5frefresh_5fcommand',['BANK_INTERFACE_PMC_HOST_REFRESH_COMMAND',['../dpu__bank__interface__pmc_8h.html#a8f43397a8671ffef7972f5bcfff7100fa0ad10cdb788333d208f70b94e7ff05c9',1,'dpu_bank_interface_pmc.h']]],
  ['bank_5finterface_5fpmc_5fldma_5finstruction',['BANK_INTERFACE_PMC_LDMA_INSTRUCTION',['../dpu__bank__interface__pmc_8h.html#a8f43397a8671ffef7972f5bcfff7100fa4eca53b97262f7c8a748254b07f57399',1,'dpu_bank_interface_pmc.h']]],
  ['bank_5finterface_5fpmc_5fread_5f64bit_5finstruction',['BANK_INTERFACE_PMC_READ_64BIT_INSTRUCTION',['../dpu__bank__interface__pmc_8h.html#a8f43397a8671ffef7972f5bcfff7100fa76dbe54c7bd15552a7a53e506a35892c',1,'dpu_bank_interface_pmc.h']]],
  ['bank_5finterface_5fpmc_5frow_5fhammer_5frefresh_5fcommand',['BANK_INTERFACE_PMC_ROW_HAMMER_REFRESH_COMMAND',['../dpu__bank__interface__pmc_8h.html#a8f43397a8671ffef7972f5bcfff7100fa33ce019947c771d1248146d7d3e06dbe',1,'dpu_bank_interface_pmc.h']]],
  ['bank_5finterface_5fpmc_5fsdma_5finstruction',['BANK_INTERFACE_PMC_SDMA_INSTRUCTION',['../dpu__bank__interface__pmc_8h.html#a8f43397a8671ffef7972f5bcfff7100fa4b88d2c607c538e4356a86ae92cf2967',1,'dpu_bank_interface_pmc.h']]],
  ['bank_5finterface_5fpmc_5fwrite_5f64bit_5finstruction',['BANK_INTERFACE_PMC_WRITE_64BIT_INSTRUCTION',['../dpu__bank__interface__pmc_8h.html#a8f43397a8671ffef7972f5bcfff7100faabfe56c6fafe74bb8f90ccc8406e3fbb',1,'dpu_bank_interface_pmc.h']]]
];
