var searchData=
[
  ['target',['target',['../struct__dpu__loader__env__t.html#ac7e9eb9ff6b7682adbd22dff97a8a844',1,'_dpu_loader_env_t']]],
  ['thread_5fprofiling',['thread_profiling',['../struct__dpu__elf__runtime__info.html#a732f758dc2a8745bf44ddabe4a0d45f9',1,'_dpu_elf_runtime_info']]],
  ['thread_5fprofiling_5faddress',['thread_profiling_address',['../struct__dpu__profiling__context__t.html#a60447045762f7835ff7c081335f8e7cd',1,'_dpu_profiling_context_t::thread_profiling_address()'],['../structdpu__program__t.html#a60b09615ccc6b349db273722fba69787',1,'dpu_program_t::thread_profiling_address()']]],
  ['time_5ffor_5fretry',['time_for_retry',['../structdpu__fifo__rank__t.html#ae4a4d8b3e3b8fabb8e5217a769a84459',1,'dpu_fifo_rank_t']]],
  ['timings',['timings',['../structdpu__hw__description__t.html#a0345a61a7b1e2c1eca1b68be49a67f26',1,'dpu_hw_description_t']]],
  ['topology',['topology',['../structdpu__hw__description__t.html#a4e460e0572da6cf09684d74d244c6b17',1,'dpu_hw_description_t']]],
  ['transfer_5fmatrix',['transfer_matrix',['../structdpu__fifo__rank__t.html#aaebdc9a0953047894c97c5c00d800b49',1,'dpu_fifo_rank_t']]],
  ['two_5f32bits',['two_32bits',['../structbank__interface__pmc__result__t.html#adabd8153d5092791fecf757ada3f9bdb',1,'bank_interface_pmc_result_t']]],
  ['type',['type',['../struct__dpu__description__t.html#a0cc9dbfa4e34ec2df31b8a1e9909cb57',1,'_dpu_description_t::type()'],['../structdpu__transfer__matrix.html#ae9c38cbee3b489cf4fd22d1e5e48f1e1',1,'dpu_transfer_matrix::type()']]]
];
