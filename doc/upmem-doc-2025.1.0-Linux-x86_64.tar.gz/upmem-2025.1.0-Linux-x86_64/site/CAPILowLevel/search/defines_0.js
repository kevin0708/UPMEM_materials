var searchData=
[
  ['_5f_5fmaybe_5funused_5f_5f',['__MAYBE_UNUSED__',['../dpu__chip__id_8h.html#a72cd516233208b118a87ec6ce555b7d3',1,'__MAYBE_UNUSED__():&#160;dpu_chip_id.h'],['../dpu__target_8h.html#a72cd516233208b118a87ec6ce555b7d3',1,'__MAYBE_UNUSED__():&#160;dpu_target.h']]],
  ['_5fstruct_5fdpu_5fforeach_5fi',['_STRUCT_DPU_FOREACH_I',['../dpu__management_8h.html#aa77b786686f760e0a13601fec123c3ac',1,'dpu_management.h']]],
  ['_5fstruct_5fdpu_5fforeach_5fx',['_STRUCT_DPU_FOREACH_X',['../dpu__management_8h.html#a04688b7ce29650b953ba6591df952623',1,'dpu_management.h']]]
];
