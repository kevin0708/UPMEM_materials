var struct__dpu__loader__env__t =
[
    [ "dpu", "struct__dpu__loader__env__t.html#a99bfe1cefdde85ed6e56d8916e6bc3d4", null ],
    [ "rank", "struct__dpu__loader__env__t.html#a2fd359152e22622599dfd985fa0a16d0", null ],
    [ "target", "struct__dpu__loader__env__t.html#ac7e9eb9ff6b7682adbd22dff97a8a844", null ]
];