var dpu__target_8h =
[
    [ "__MAYBE_UNUSED__", "dpu__target_8h.html#a72cd516233208b118a87ec6ce555b7d3", null ],
    [ "dpu_type_t", "dpu__target_8h.html#a7519b634779b035b645069015bcbf461", null ],
    [ "_dpu_type_t", "dpu__target_8h.html#a1c2b3f30c203ce1084696d518a7e5780", [
      [ "FUNCTIONAL_SIMULATOR", "dpu__target_8h.html#a1c2b3f30c203ce1084696d518a7e5780abaaa134c357f9e4ff561e70a2858ab2a", null ],
      [ "CYCLE_ACCURATE_SIMULATOR", "dpu__target_8h.html#a1c2b3f30c203ce1084696d518a7e5780afdc0d50fa56784d34337d24953eaf907", null ],
      [ "RTL_SIMULATOR", "dpu__target_8h.html#a1c2b3f30c203ce1084696d518a7e5780a09d38a6dd43901114c244850cec8ffa0", null ],
      [ "HW", "dpu__target_8h.html#a1c2b3f30c203ce1084696d518a7e5780aba9198abb85a0609d4980b923cc8d168", null ],
      [ "BACKUP_SPI", "dpu__target_8h.html#a1c2b3f30c203ce1084696d518a7e5780a0070ab198c137532f6b0bc5529fc57a5", null ],
      [ "SCENARIO", "dpu__target_8h.html#a1c2b3f30c203ce1084696d518a7e5780ad2d33871d5de0fe31809925c9087c2d1", null ],
      [ "NB_OF_DPU_TYPES", "dpu__target_8h.html#a1c2b3f30c203ce1084696d518a7e5780a69fe83dedc9f8ba257a72ae0a82989c7", null ]
    ] ],
    [ "dpu_type_from_profile_string", "dpu__target_8h.html#a73ba286ff310d28af5716b98273626df", null ],
    [ "dpu_type_to_string", "dpu__target_8h.html#a678e05bce24733b6087aad9a4cdffb82", null ]
];