var structdpu__vpd__header =
[
    [ "__padding_0", "structdpu__vpd__header.html#ae5904472d493f89b9ce67c30efc4050e", null ],
    [ "__padding_1", "structdpu__vpd__header.html#a76f8a15eda0551035854eedb427134ad", null ],
    [ "rank_count", "structdpu__vpd__header.html#a8784808b14b6778d9851d5fce28e432d", null ],
    [ "ranks", "structdpu__vpd__header.html#a7915a3f634d002a56982c81018de27d1", null ],
    [ "repair_count", "structdpu__vpd__header.html#a3b74c1114bfce530beaed23e3707ef16", null ],
    [ "struct_id", "structdpu__vpd__header.html#aa5326df180cb23c59afbcab711a06479", null ],
    [ "struct_size", "structdpu__vpd__header.html#a3411425b545585f06b75516b5291a6ac", null ],
    [ "struct_ver", "structdpu__vpd__header.html#a2ab8dec45245c61c730298605dde55c1", null ]
];