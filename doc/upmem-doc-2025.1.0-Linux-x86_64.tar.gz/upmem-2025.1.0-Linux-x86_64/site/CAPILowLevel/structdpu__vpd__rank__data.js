var structdpu__vpd__rank__data =
[
    [ "dpu_disabled", "structdpu__vpd__rank__data.html#a1e3bc8d47d59b9ff7a25aabcf8d8ab07", null ],
    [ "iram_repair", "structdpu__vpd__rank__data.html#a36a53c86f1522d4906ecc4fb027a0860", null ],
    [ "wram_repair", "structdpu__vpd__rank__data.html#a8623b45d220d6701e174aa61c07064ed", null ]
];