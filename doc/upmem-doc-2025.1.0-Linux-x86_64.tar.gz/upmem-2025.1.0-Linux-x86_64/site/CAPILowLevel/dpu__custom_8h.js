var dpu__custom_8h =
[
    [ "dpu_custom_command_args_t", "dpu__custom_8h.html#a997c40bdc49fea0c151112583ff5c342", null ],
    [ "dpu_custom_command_t", "dpu__custom_8h.html#a23175d28cfaf387800abf702d32402eb", null ],
    [ "_dpu_custom_command_t", "dpu__custom_8h.html#ab228fc8008d21d42cf217bad848afa48", [
      [ "DPU_COMMAND_DPU_SOFT_RESET", "dpu__custom_8h.html#ab228fc8008d21d42cf217bad848afa48adf8f4d7fd6d3340d3370f6d2195ecfcc", null ],
      [ "DPU_COMMAND_ALL_SOFT_RESET", "dpu__custom_8h.html#ab228fc8008d21d42cf217bad848afa48a6ec19990dea829c7aca22c3cd5ad9898", null ],
      [ "DPU_COMMAND_DPU_PREEXECUTION", "dpu__custom_8h.html#ab228fc8008d21d42cf217bad848afa48aa18b7edb4ee6bb14feec0bcfcc68117a", null ],
      [ "DPU_COMMAND_ALL_PREEXECUTION", "dpu__custom_8h.html#ab228fc8008d21d42cf217bad848afa48a4c4a9f28062d29b60f6b0dde6f02372f", null ],
      [ "DPU_COMMAND_DPU_POSTEXECUTION", "dpu__custom_8h.html#ab228fc8008d21d42cf217bad848afa48a7cd2edd6851a289beef600c73070d82a", null ],
      [ "DPU_COMMAND_ALL_POSTEXECUTION", "dpu__custom_8h.html#ab228fc8008d21d42cf217bad848afa48a7d01d824b3cca663c785588b104440ee", null ],
      [ "DPU_COMMAND_CUSTOM_LABEL", "dpu__custom_8h.html#ab228fc8008d21d42cf217bad848afa48ae75b5c1b14c8cd035103d24493e851ad", null ],
      [ "DPU_COMMAND_POSTMORTEM", "dpu__custom_8h.html#ab228fc8008d21d42cf217bad848afa48a4e57cfc8d91d17dadb68e018831ad3fe", null ],
      [ "DPU_COMMAND_SYSTEM_REPORT", "dpu__custom_8h.html#ab228fc8008d21d42cf217bad848afa48aef4b13ff61219f4d8fed0111fc119066", null ],
      [ "DPU_COMMAND_BINARY_PATH", "dpu__custom_8h.html#ab228fc8008d21d42cf217bad848afa48afa6493b07109707524c20600efed5c5a", null ],
      [ "DPU_COMMAND_EVENT_START", "dpu__custom_8h.html#ab228fc8008d21d42cf217bad848afa48ae72fa244e6c184d0e611cfa24a802535", null ],
      [ "DPU_COMMAND_EVENT_END", "dpu__custom_8h.html#ab228fc8008d21d42cf217bad848afa48ab8dc80cda7653755602de63b821a31d8", null ],
      [ "DPU_COMMAND_SET_SLICE_INFO", "dpu__custom_8h.html#ab228fc8008d21d42cf217bad848afa48afe5aaecdb33bc113ea498c23f5635cb4", null ]
    ] ],
    [ "dpu_custom_for_dpu", "dpu__custom_8h.html#afcb0327346f103ed731ea8d4a4c38e66", null ],
    [ "dpu_custom_for_rank", "dpu__custom_8h.html#a9950586c990505a6e161a4dcf5c16848", null ]
];