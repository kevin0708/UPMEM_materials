var structdpu__vpd__repair__entry =
[
    [ "__padding", "structdpu__vpd__repair__entry.html#a3813647e1bc868a81623e07c5e32bd51", null ],
    [ "address", "structdpu__vpd__repair__entry.html#a643d30df67a67c5915fde941c934f9f8", null ],
    [ "bank", "structdpu__vpd__repair__entry.html#aaccbfb752723bf7af1abb8b0fe9858bc", null ],
    [ "bits", "structdpu__vpd__repair__entry.html#a824af546b997aeefcb71a5fe0eda3a0a", null ],
    [ "ci", "structdpu__vpd__repair__entry.html#a6ae95b90a8247d90fef62b51d9e60e25", null ],
    [ "dpu", "structdpu__vpd__repair__entry.html#a78ded4b3610cb2c77528b8fffd12efbf", null ],
    [ "iram_wram", "structdpu__vpd__repair__entry.html#ac4bfa5b6b7bef57afa7642aaaa103c0d", null ],
    [ "rank", "structdpu__vpd__repair__entry.html#a3b6f67f63ff4937bf7ee67d80f49f500", null ]
];