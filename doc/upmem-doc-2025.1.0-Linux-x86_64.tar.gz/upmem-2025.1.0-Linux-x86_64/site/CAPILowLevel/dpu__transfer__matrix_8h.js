var dpu__transfer__matrix_8h =
[
    [ "dpu_transfer_matrix", "structdpu__transfer__matrix.html", "structdpu__transfer__matrix" ],
    [ "MAX_NR_DPUS_PER_RANK", "dpu__transfer__matrix_8h.html#a922f398fbb1480797d82f33a5e04a6c3", null ],
    [ "struct_dpu_transfer_matrix_t", "dpu__transfer__matrix_8h.html#a974f4b548ec61d245e290df906dd2d88", null ],
    [ "dpu_transfer_matrix_add_dpu", "dpu__transfer__matrix_8h.html#a341c982b4928bbc2023ffcff83e02d3f", null ],
    [ "dpu_transfer_matrix_add_dpu_block", "dpu__transfer__matrix_8h.html#a8868709f523ba8e58347b3a62ff7c42b", null ],
    [ "dpu_transfer_matrix_clear_all", "dpu__transfer__matrix_8h.html#a1078b0db98037178f652d76b99c77de0", null ],
    [ "dpu_transfer_matrix_clear_dpu", "dpu__transfer__matrix_8h.html#ab5863f3942ee05117b491d7a523040da", null ],
    [ "dpu_transfer_matrix_copy", "dpu__transfer__matrix_8h.html#a8d563ff6af20bd7f6c0173a52dff5707", null ],
    [ "dpu_transfer_matrix_get_ptr", "dpu__transfer__matrix_8h.html#a2d47e6e078da1e8a724a39e8365b44d9", null ],
    [ "dpu_transfer_matrix_set_all", "dpu__transfer__matrix_8h.html#ae92e4418c430b8cac5481b70ad948981", null ]
];