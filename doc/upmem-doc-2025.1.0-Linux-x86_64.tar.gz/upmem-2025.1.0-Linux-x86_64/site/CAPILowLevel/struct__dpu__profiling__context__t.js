var struct__dpu__profiling__context__t =
[
    [ "address", "struct__dpu__profiling__context__t.html#adda4897d6088ea3d1743355b7a1c2c94", null ],
    [ "count", "struct__dpu__profiling__context__t.html#afcc68e9eec57ce069fcdc37815837d6d", null ],
    [ "dpu", "struct__dpu__profiling__context__t.html#a99bfe1cefdde85ed6e56d8916e6bc3d4", null ],
    [ "enable_profiling", "struct__dpu__profiling__context__t.html#ab47c64ca966ed8ae690bf650044c83bb", null ],
    [ "mcount_address", "struct__dpu__profiling__context__t.html#a4fbf6a900a47c47aa37fffd874050f20", null ],
    [ "mcount_stats", "struct__dpu__profiling__context__t.html#ad78f3e3820da3eea24148af4f71c3df2", null ],
    [ "nr_of_mcount_stats", "struct__dpu__profiling__context__t.html#a0e321d3666a8d99c9ea2d01d023f45e9", null ],
    [ "perfcounter_end_value_address", "struct__dpu__profiling__context__t.html#a3468a9aa70ab7fa5052ace33ffed20bc", null ],
    [ "profiling_symbols", "struct__dpu__profiling__context__t.html#a64c746a77530797560f9211576e80e9a", null ],
    [ "ret_mcount_address", "struct__dpu__profiling__context__t.html#a8a1662f36909bef6dae57dcd7ed70af8", null ],
    [ "sample_stats", "struct__dpu__profiling__context__t.html#ad951f2f3f72e8896313cf18f779bd5ef", null ],
    [ "thread_profiling_address", "struct__dpu__profiling__context__t.html#a60447045762f7835ff7c081335f8e7cd", null ]
];