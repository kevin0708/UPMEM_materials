var dpu__bank__interface__pmc_8h =
[
    [ "bank_interface_pmc_config_t", "structbank__interface__pmc__config__t.html", "structbank__interface__pmc__config__t" ],
    [ "bank_interface_pmc_result_t", "structbank__interface__pmc__result__t.html", "structbank__interface__pmc__result__t" ],
    [ "bank_interface_pmc_event_t", "dpu__bank__interface__pmc_8h.html#a8f43397a8671ffef7972f5bcfff7100f", [
      [ "BANK_INTERFACE_PMC_NONE", "dpu__bank__interface__pmc_8h.html#a8f43397a8671ffef7972f5bcfff7100fa0e54a28ef28fc292e6669acede299509", null ],
      [ "BANK_INTERFACE_PMC_LDMA_INSTRUCTION", "dpu__bank__interface__pmc_8h.html#a8f43397a8671ffef7972f5bcfff7100fa4eca53b97262f7c8a748254b07f57399", null ],
      [ "BANK_INTERFACE_PMC_SDMA_INSTRUCTION", "dpu__bank__interface__pmc_8h.html#a8f43397a8671ffef7972f5bcfff7100fa4b88d2c607c538e4356a86ae92cf2967", null ],
      [ "BANK_INTERFACE_PMC_READ_64BIT_INSTRUCTION", "dpu__bank__interface__pmc_8h.html#a8f43397a8671ffef7972f5bcfff7100fa76dbe54c7bd15552a7a53e506a35892c", null ],
      [ "BANK_INTERFACE_PMC_WRITE_64BIT_INSTRUCTION", "dpu__bank__interface__pmc_8h.html#a8f43397a8671ffef7972f5bcfff7100faabfe56c6fafe74bb8f90ccc8406e3fbb", null ],
      [ "BANK_INTERFACE_PMC_HOST_ACTIVATE_COMMAND", "dpu__bank__interface__pmc_8h.html#a8f43397a8671ffef7972f5bcfff7100fa78379824b82aac7545210246166006fc", null ],
      [ "BANK_INTERFACE_PMC_HOST_REFRESH_COMMAND", "dpu__bank__interface__pmc_8h.html#a8f43397a8671ffef7972f5bcfff7100fa0ad10cdb788333d208f70b94e7ff05c9", null ],
      [ "BANK_INTERFACE_PMC_ROW_HAMMER_REFRESH_COMMAND", "dpu__bank__interface__pmc_8h.html#a8f43397a8671ffef7972f5bcfff7100fa33ce019947c771d1248146d7d3e06dbe", null ],
      [ "BANK_INTERFACE_PMC_CYCLES", "dpu__bank__interface__pmc_8h.html#a8f43397a8671ffef7972f5bcfff7100fa0ff7ceeb48178efbae757d5f96e93a5c", null ]
    ] ],
    [ "bank_interface_pmc_mode_t", "dpu__bank__interface__pmc_8h.html#a511fcff23a801ff448640bc47ba79035", [
      [ "BANK_INTERFACE_PMC_32BIT_MODE", "dpu__bank__interface__pmc_8h.html#a511fcff23a801ff448640bc47ba79035acef261b2602792eb08f42f8021a7c60a", null ],
      [ "BANK_INTERFACE_PMC_64BIT_MODE", "dpu__bank__interface__pmc_8h.html#a511fcff23a801ff448640bc47ba79035a220b4dd174758fe8fe6a4d9d54b826af", null ]
    ] ],
    [ "dpu_bank_interface_pmc_disable", "dpu__bank__interface__pmc_8h.html#a06b8858e329035e33f885ead315d4608", null ],
    [ "dpu_bank_interface_pmc_enable", "dpu__bank__interface__pmc_8h.html#af11e95da9e98cfe103ac3f5293980523", null ],
    [ "dpu_bank_interface_pmc_read_counters", "dpu__bank__interface__pmc_8h.html#ac07e3abaa60d5853cebc5bf7e2b60819", null ],
    [ "dpu_bank_interface_pmc_stop_counters", "dpu__bank__interface__pmc_8h.html#a425684aaee608fa506019c8130731448", null ]
];