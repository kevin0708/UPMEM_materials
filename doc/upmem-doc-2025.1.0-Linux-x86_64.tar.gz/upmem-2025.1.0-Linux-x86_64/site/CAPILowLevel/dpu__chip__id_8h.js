var dpu__chip__id_8h =
[
    [ "__MAYBE_UNUSED__", "dpu__chip__id_8h.html#a72cd516233208b118a87ec6ce555b7d3", null ],
    [ "NEXT_DPU_CHIP_IDX", "dpu__chip__id_8h.html#a489d0fcc6a10a82ece5ab2051467d4ed", null ],
    [ "dpu_chip_id_e", "dpu__chip__id_8h.html#a810f6425241611bb36af956d55851b9f", null ],
    [ "_dpu_chip_id_e", "dpu__chip__id_8h.html#af46a0ba336dddd2d868ee71f3747137d", [
      [ "vD", "dpu__chip__id_8h.html#af46a0ba336dddd2d868ee71f3747137da550fb24c9a3eb077210f13b3e98455da", null ],
      [ "vD_cas", "dpu__chip__id_8h.html#af46a0ba336dddd2d868ee71f3747137dabdf065de0aa144f8f8f783c3008d6de8", null ],
      [ "vD_fun", "dpu__chip__id_8h.html#af46a0ba336dddd2d868ee71f3747137dab88d19e0e7c20e9b82110808c1de0379", null ],
      [ "vD_asic1", "dpu__chip__id_8h.html#af46a0ba336dddd2d868ee71f3747137daaf305f1d79271e1add28c613a8bbbc72", null ],
      [ "vD_asic8", "dpu__chip__id_8h.html#af46a0ba336dddd2d868ee71f3747137dafa73e54cc04e327f6a0a24b64fcdd0b8", null ],
      [ "vD_fpga1", "dpu__chip__id_8h.html#af46a0ba336dddd2d868ee71f3747137dabf185c2803a5bf3114824b1bbedc6d5a", null ],
      [ "vD_fpga8", "dpu__chip__id_8h.html#af46a0ba336dddd2d868ee71f3747137da247ee3e5a47009946d03890ef6ff4a2e", null ],
      [ "vD_asic4", "dpu__chip__id_8h.html#af46a0ba336dddd2d868ee71f3747137da5e0194d77fa334e8f483acd605952919", null ],
      [ "vD_fpga4", "dpu__chip__id_8h.html#af46a0ba336dddd2d868ee71f3747137da93b2b0c5a9457dcc1ae28efab6292448", null ],
      [ "vD_fun_v1_4", "dpu__chip__id_8h.html#af46a0ba336dddd2d868ee71f3747137da04cb7bd63c7a9e8d2d2ff8db856646cc", null ],
      [ "vD_asic1_v1_4", "dpu__chip__id_8h.html#af46a0ba336dddd2d868ee71f3747137dae299c99b93837164746d4493f38ecc5f", null ],
      [ "vD_asic8_v1_4", "dpu__chip__id_8h.html#af46a0ba336dddd2d868ee71f3747137da3d956caeb470f674457bf3424092a3cd", null ],
      [ "vD_fpga1_v1_4", "dpu__chip__id_8h.html#af46a0ba336dddd2d868ee71f3747137da7bb5070724213bb73554cfebdbbd1227", null ],
      [ "vD_fpga8_v1_4", "dpu__chip__id_8h.html#af46a0ba336dddd2d868ee71f3747137da4fab33cc05055239975306f269152449", null ],
      [ "vD_asic4_v1_4", "dpu__chip__id_8h.html#af46a0ba336dddd2d868ee71f3747137daedbde22cbdf743d1e0b830e9aaefa863", null ],
      [ "vD_fpga4_v1_4", "dpu__chip__id_8h.html#af46a0ba336dddd2d868ee71f3747137dae00aad6ab91da540b9d4ae4e64155352", null ]
    ] ],
    [ "chip_id_to_idx", "dpu__chip__id_8h.html#ad3a2942322767eceab4eb9814f3f7bbb", null ]
];