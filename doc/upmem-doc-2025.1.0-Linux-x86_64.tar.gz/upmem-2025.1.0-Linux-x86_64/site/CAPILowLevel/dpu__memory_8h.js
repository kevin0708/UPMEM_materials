var dpu__memory_8h =
[
    [ "dpu_copy_from_iram_for_dpu", "dpu__memory_8h.html#a022e8d380efcc12fd0e920ee3f3daec7", null ],
    [ "dpu_copy_from_iram_for_matrix", "dpu__memory_8h.html#a68223ba74c899095d9cd24acb272f072", null ],
    [ "dpu_copy_from_mram", "dpu__memory_8h.html#a22121ea1d5ae305e9badc1debfc92271", null ],
    [ "dpu_copy_from_mrams", "dpu__memory_8h.html#a0e0c837216ebeffb62ce427307f44811", null ],
    [ "dpu_copy_from_wram_fifo", "dpu__memory_8h.html#a814ea62347e8edab2dd14ce891514a5c", null ],
    [ "dpu_copy_from_wram_for_dpu", "dpu__memory_8h.html#ae46b3446a6616b61b274f97bc93788cd", null ],
    [ "dpu_copy_from_wram_for_matrix", "dpu__memory_8h.html#a2d4d715ad53e7fa9cca9325deeb8e278", null ],
    [ "dpu_copy_to_iram_for_dpu", "dpu__memory_8h.html#a6719ae535ada259e2e659405a784bb5a", null ],
    [ "dpu_copy_to_iram_for_matrix", "dpu__memory_8h.html#ad7697a3efe0fadeef2b35827333d9626", null ],
    [ "dpu_copy_to_iram_for_rank", "dpu__memory_8h.html#af8c4b24895acc77da19e483d6a90e2e6", null ],
    [ "dpu_copy_to_mram", "dpu__memory_8h.html#a66e9ccbcd5ec3f7767441a0926f24538", null ],
    [ "dpu_copy_to_mrams", "dpu__memory_8h.html#a786e9d4549a74de12b7809ca4d7c6aa8", null ],
    [ "dpu_copy_to_wram_fifo", "dpu__memory_8h.html#a4c58b1d7af0d3a28ca3a6b4fa80c7e82", null ],
    [ "dpu_copy_to_wram_for_dpu", "dpu__memory_8h.html#a20001805600620fdcf5a1873c653a5cb", null ],
    [ "dpu_copy_to_wram_for_matrix", "dpu__memory_8h.html#ae089609e2b474144a2e33948c2ec4c63", null ],
    [ "dpu_copy_to_wram_for_rank", "dpu__memory_8h.html#ad97985ba425c86f8511c6d28468d353c", null ]
];