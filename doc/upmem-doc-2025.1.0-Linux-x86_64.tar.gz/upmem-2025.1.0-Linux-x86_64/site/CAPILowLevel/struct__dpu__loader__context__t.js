var struct__dpu__loader__context__t =
[
    [ "dummy", "struct__dpu__loader__context__t.html#a44b7a3baf02bac7ad707e8f2f5eca1ca", null ],
    [ "env", "struct__dpu__loader__context__t.html#aef66982a519b9a9e771a28cf0f905448", null ],
    [ "nr_of_instructions", "struct__dpu__loader__context__t.html#a88cbd0e23918636ed006ebfa961c0685", null ],
    [ "nr_of_mram_bytes", "struct__dpu__loader__context__t.html#aae7c9b30f63026fb8f87a60fab1377dc", null ],
    [ "nr_of_wram_words", "struct__dpu__loader__context__t.html#a32846d14568cd4ba99987d74974f2df7", null ],
    [ "patch_iram", "struct__dpu__loader__context__t.html#aec9af54321dc1a609e5503c243119828", null ],
    [ "patch_mram", "struct__dpu__loader__context__t.html#a73ace42607d5101c9f715db328934018", null ],
    [ "patch_wram", "struct__dpu__loader__context__t.html#a52546ffa30930cca4571b36d541459e8", null ]
];