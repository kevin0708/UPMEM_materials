var dpu__profiler_8h =
[
    [ "_dpu_profiling_context_t", "struct__dpu__profiling__context__t.html", "struct__dpu__profiling__context__t" ],
    [ "dpu_profiling_context_t", "dpu__profiler_8h.html#af05f8e69a2d7a08f2ab10126c4cb8e09", null ],
    [ "dpu_profiling_type_e", "dpu__profiler_8h.html#a8d1000224ceda181d11edc325b75acd3", [
      [ "DPU_PROFILING_NOP", "dpu__profiler_8h.html#a8d1000224ceda181d11edc325b75acd3a5466b61de4ffa49ebf2fe290b47c1d2d", null ],
      [ "DPU_PROFILING_MCOUNT", "dpu__profiler_8h.html#a8d1000224ceda181d11edc325b75acd3adc2c8c3ba4488197e4683828a476c99d", null ],
      [ "DPU_PROFILING_STATS", "dpu__profiler_8h.html#a8d1000224ceda181d11edc325b75acd3a91d4ec81da831c56ce8829f26b3e8510", null ],
      [ "DPU_PROFILING_SAMPLES", "dpu__profiler_8h.html#a8d1000224ceda181d11edc325b75acd3a6154881cc104eab08d1598f220869cc6", null ],
      [ "DPU_PROFILING_SECTIONS", "dpu__profiler_8h.html#a8d1000224ceda181d11edc325b75acd3afc169783252b5ba1071c7038f62d63ff", null ]
    ] ],
    [ "dpu_collect_samples_profiling", "dpu__profiler_8h.html#afca482a8fa8826283d197a421882db3b", null ],
    [ "dpu_collect_statistics_profiling", "dpu__profiler_8h.html#a48ce294a448b4f3cfffeafa5502ce200", null ],
    [ "dpu_dump_samples_profiling", "dpu__profiler_8h.html#a4f4be3cfe00416300a3beacf24278554", null ],
    [ "dpu_dump_section_profiling", "dpu__profiler_8h.html#ac6828649d4b1d61bba8f3c648b4fec93", null ],
    [ "dpu_dump_statistics_profiling", "dpu__profiler_8h.html#ad462241456d60d0a5017886853e68610", null ],
    [ "dpu_fill_profiling_info", "dpu__profiler_8h.html#af43f0cf184c26d75672c722329dcb37e", null ],
    [ "dpu_get_profiling_context", "dpu__profiler_8h.html#a4cc52d71b29f4c7fdbf6340b41f24e22", null ],
    [ "dpu_patch_profiling_for_dpu", "dpu__profiler_8h.html#a45bd36c9f37b1a7817175bd8865a6f4c", null ],
    [ "dpu_set_magic_profiling_for_dpu", "dpu__profiler_8h.html#a85a0258289bb3b5c6992c35e93cd907a", null ]
];