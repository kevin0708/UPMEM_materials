var dpu__vpd__structures_8h =
[
    [ "dpu_vpd_rank_data", "structdpu__vpd__rank__data.html", "structdpu__vpd__rank__data" ],
    [ "dpu_vpd_repair_entry", "structdpu__vpd__repair__entry.html", "structdpu__vpd__repair__entry" ],
    [ "dpu_vpd_header", "structdpu__vpd__header.html", "structdpu__vpd__header" ],
    [ "dpu_vpd", "structdpu__vpd.html", "structdpu__vpd" ],
    [ "dpu_vpd_string_pair", "structdpu__vpd__string__pair.html", "structdpu__vpd__string__pair" ],
    [ "dpu_vpd_database", "structdpu__vpd__database.html", "structdpu__vpd__database" ],
    [ "NB_MAX_REPAIR", "dpu__vpd__structures_8h.html#a439fecfe7384f66788413ffb91c08086", null ],
    [ "VPD_MAX_RANK", "dpu__vpd__structures_8h.html#a76bde86586fa074cc66700085b96546b", null ],
    [ "VPD_MAX_SIZE", "dpu__vpd__structures_8h.html#adb543da16553538e91023b95f7f7f8f1", null ],
    [ "VPD_STRUCT_ID", "dpu__vpd__structures_8h.html#ae8821b9f863b8d8961c055462ce6b3ca", null ],
    [ "VPD_STRUCT_VERSION", "dpu__vpd__structures_8h.html#aa16a2fa4af34c9c9c1e31fe97489621c", null ],
    [ "VPD_UNDEFINED_REPAIR_COUNT", "dpu__vpd__structures_8h.html#a9ebd1bd60b12684d353ad839e04a0b9a", null ],
    [ "dpu_vpd_error", "dpu__vpd__structures_8h.html#a5b9876ba970a0ab10f4d40d523ed461b", [
      [ "DPU_VPD_OK", "dpu__vpd__structures_8h.html#a5b9876ba970a0ab10f4d40d523ed461baaa6a22c8a792e5fec6cf8da89e6e1cd5", null ],
      [ "DPU_VPD_ERR_HEADER_FORMAT", "dpu__vpd__structures_8h.html#a5b9876ba970a0ab10f4d40d523ed461ba135ae07671792cdac87b89f7afdb2f59", null ],
      [ "DPU_VPD_ERR_HEADER_VERSION", "dpu__vpd__structures_8h.html#a5b9876ba970a0ab10f4d40d523ed461bacbc6057448733271b996d354f6e3226f", null ],
      [ "DPU_VPD_ERR_REPAIR_ENTRIES", "dpu__vpd__structures_8h.html#a5b9876ba970a0ab10f4d40d523ed461ba48799c92c881e456f4bfa9fb2fb1a66d", null ],
      [ "DPU_VPD_ERR_NB_MAX_REPAIR", "dpu__vpd__structures_8h.html#a5b9876ba970a0ab10f4d40d523ed461bac73947cc128e5fc62d6debac46b9e5b7", null ],
      [ "DPU_VPD_ERR_FLASH", "dpu__vpd__structures_8h.html#a5b9876ba970a0ab10f4d40d523ed461ba9aa1ac7c5ba5e65733928341fa98cc29", null ],
      [ "DPU_VPD_ERR_DPU_ALREADY_ENABLED", "dpu__vpd__structures_8h.html#a5b9876ba970a0ab10f4d40d523ed461ba5de980bfc528fd15fc08d2ef852576ff", null ],
      [ "DPU_VPD_ERR_DPU_ALREADY_DISABLED", "dpu__vpd__structures_8h.html#a5b9876ba970a0ab10f4d40d523ed461ba325e04599b58f3e12f77213df47789f5", null ],
      [ "DPU_VPD_ERR_OVERFLOW", "dpu__vpd__structures_8h.html#a5b9876ba970a0ab10f4d40d523ed461ba735e2346777838d99a5ee155c0d23b40", null ],
      [ "DPU_VPD_ERR", "dpu__vpd__structures_8h.html#a5b9876ba970a0ab10f4d40d523ed461ba4c3df0ad13c7cf620f9928407a358fa0", null ]
    ] ],
    [ "dpu_vpd_repair_type", "dpu__vpd__structures_8h.html#a88e37a08d8532a2ed8eb2c0ac1e0de51", [
      [ "DPU_VPD_REPAIR_IRAM", "dpu__vpd__structures_8h.html#a88e37a08d8532a2ed8eb2c0ac1e0de51a29537ccc88324d458824f292546fca9e", null ],
      [ "DPU_VPD_REPAIR_WRAM", "dpu__vpd__structures_8h.html#a88e37a08d8532a2ed8eb2c0ac1e0de51af9fb78b3467faa69e8e3a599b5907176", null ]
    ] ],
    [ "vpd_data_type", "dpu__vpd__structures_8h.html#a6ea39ade67644ebf7cddbe865e2540e9", [
      [ "VPD_TYPE_STRING", "dpu__vpd__structures_8h.html#a6ea39ade67644ebf7cddbe865e2540e9a547de0cea61c1f7d39d42407096441e1", null ],
      [ "VPD_TYPE_BYTE", "dpu__vpd__structures_8h.html#a6ea39ade67644ebf7cddbe865e2540e9ae119f5ed261b378875205e756c9df7bf", null ],
      [ "VPD_TYPE_SHORT", "dpu__vpd__structures_8h.html#a6ea39ade67644ebf7cddbe865e2540e9aa7f96a58e55970802e28977feaa31eaf", null ],
      [ "VPD_TYPE_INT", "dpu__vpd__structures_8h.html#a6ea39ade67644ebf7cddbe865e2540e9ad8fedd98e75ba7655e4d64e8f26b9c4d", null ],
      [ "VPD_TYPE_LONG", "dpu__vpd__structures_8h.html#a6ea39ade67644ebf7cddbe865e2540e9a5d425f372e859af9ec7b4ac57b92298d", null ],
      [ "VPD_TYPE_BYTEARRAY", "dpu__vpd__structures_8h.html#a6ea39ade67644ebf7cddbe865e2540e9a893f2ba9702157fc2ae305c6bcbfceb2", null ]
    ] ]
];