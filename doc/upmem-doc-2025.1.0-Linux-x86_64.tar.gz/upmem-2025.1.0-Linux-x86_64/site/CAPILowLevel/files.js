var files =
[
    [ "dpu_bank_interface_pmc.h", "dpu__bank__interface__pmc_8h.html", "dpu__bank__interface__pmc_8h" ],
    [ "dpu_chip_id.h", "dpu__chip__id_8h.html", "dpu__chip__id_8h" ],
    [ "dpu_config.h", "dpu__config_8h.html", "dpu__config_8h" ],
    [ "dpu_custom.h", "dpu__custom_8h.html", "dpu__custom_8h" ],
    [ "dpu_debug.h", "dpu__debug_8h.html", "dpu__debug_8h" ],
    [ "dpu_description.h", "dpu__description_8h.html", "dpu__description_8h" ],
    [ "dpu_elf.h", "dpu__elf_8h.html", "dpu__elf_8h" ],
    [ "dpu_fifo.h", "dpu__fifo_8h_source.html", null ],
    [ "dpu_hw_description.h", "dpu__hw__description_8h.html", [
      [ "dpu_hw_description_t", "structdpu__hw__description__t.html", "structdpu__hw__description__t" ]
    ] ],
    [ "dpu_loader.h", "dpu__loader_8h.html", "dpu__loader_8h" ],
    [ "dpu_log.h", "dpu__log_8h.html", "dpu__log_8h" ],
    [ "dpu_log_internals.h", "dpu__log__internals_8h.html", "dpu__log__internals_8h" ],
    [ "dpu_management.h", "dpu__management_8h.html", "dpu__management_8h" ],
    [ "dpu_memory.h", "dpu__memory_8h.html", "dpu__memory_8h" ],
    [ "dpu_profiler.h", "dpu__profiler_8h.html", "dpu__profiler_8h" ],
    [ "dpu_program.h", "dpu__program_8h.html", "dpu__program_8h" ],
    [ "dpu_runner.h", "dpu__runner_8h.html", "dpu__runner_8h" ],
    [ "dpu_target.h", "dpu__target_8h.html", "dpu__target_8h" ],
    [ "dpu_transfer_matrix.h", "dpu__transfer__matrix_8h.html", "dpu__transfer__matrix_8h" ],
    [ "dpu_vpd.h", "dpu__vpd_8h.html", "dpu__vpd_8h" ],
    [ "dpu_vpd_structures.h", "dpu__vpd__structures_8h.html", "dpu__vpd__structures_8h" ]
];