var dpu__config_8h =
[
    [ "dpu_reset_dpu", "dpu__config_8h.html#a8974a453fbd4a48f1c20bff2dc2ee274", null ],
    [ "dpu_reset_rank", "dpu__config_8h.html#a50f09d9b0a94515fa611ebaae2d8c33d", null ]
];