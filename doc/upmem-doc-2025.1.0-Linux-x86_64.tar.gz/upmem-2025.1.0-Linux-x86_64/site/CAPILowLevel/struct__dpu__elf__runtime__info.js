var struct__dpu__elf__runtime__info =
[
    [ "barrier_info", "struct__dpu__elf__runtime__info.html#ad5a288d124ad9b0155b499a1dbd38a4b", null ],
    [ "close_print_sequence", "struct__dpu__elf__runtime__info.html#a7c7cdce40017ddd41a5f170b0fdf5ecd", null ],
    [ "mcount", "struct__dpu__elf__runtime__info.html#ada422cf0ba3ccfd2696c7135cc6e0ae6", null ],
    [ "mutex_info", "struct__dpu__elf__runtime__info.html#a354ac809f522d68abfaaeee1f34bc386", null ],
    [ "nr_threads", "struct__dpu__elf__runtime__info.html#af3202706bd841d558c2bcc80e0f601f0", null ],
    [ "open_print_sequence", "struct__dpu__elf__runtime__info.html#a12ee6ee057ff17cc13d85ce9459646fe", null ],
    [ "perfcounter_end_value", "struct__dpu__elf__runtime__info.html#afca0738799146fea9e60153e0bb8312a", null ],
    [ "printf_buffer", "struct__dpu__elf__runtime__info.html#a2763941fa4ea2d99adfe517624d313a3", null ],
    [ "printf_state", "struct__dpu__elf__runtime__info.html#a78179d35531b05a6467cde88eb9b84be", null ],
    [ "ret_mcount", "struct__dpu__elf__runtime__info.html#abb999c6ec4f5c354ad45199b9f3782bd", null ],
    [ "semaphore_info", "struct__dpu__elf__runtime__info.html#a71356ee99c61e53f511487d334aa43d0", null ],
    [ "sys_end", "struct__dpu__elf__runtime__info.html#a39c3b2862d14bd30d9200e185b5717d6", null ],
    [ "sys_heap_pointer", "struct__dpu__elf__runtime__info.html#a4d0aab9f5b7eb6365663e612785aec3a", null ],
    [ "sys_heap_pointer_reset", "struct__dpu__elf__runtime__info.html#ac0cb1cd63bfadd97eb5f0af0d4dc01a2", null ],
    [ "sys_stack_table", "struct__dpu__elf__runtime__info.html#a1eb15942004ead06d5b36b9829891bf8", null ],
    [ "sys_wq_table", "struct__dpu__elf__runtime__info.html#a2dc95e8ed11095aadbac2bbca191d9d1", null ],
    [ "thread_profiling", "struct__dpu__elf__runtime__info.html#a732f758dc2a8745bf44ddabe4a0d45f9", null ]
];