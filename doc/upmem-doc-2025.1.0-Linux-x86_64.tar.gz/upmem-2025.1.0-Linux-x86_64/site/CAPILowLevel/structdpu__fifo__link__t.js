var structdpu__fifo__link__t =
[
    [ "direction", "structdpu__fifo__link__t.html#a9840d712bf5f533cdc05b80a2219631e", null ],
    [ "fifo_symbol", "structdpu__fifo__link__t.html#abba4a4fc1e610a301bb527ac860982f8", null ],
    [ "rank_fifos", "structdpu__fifo__link__t.html#a48ecc0ceb5ec01cc0a587588c357d1b5", null ]
];