var structdpu__program__t =
[
    [ "close_print_sequence_addr", "structdpu__program__t.html#a076a80220172c3e7fe04ecd59934b54e", null ],
    [ "mcount_address", "structdpu__program__t.html#a9805e15d403826afd614fda8a980f230", null ],
    [ "nr_threads_enabled", "structdpu__program__t.html#ae618481df1a4432f868d69d508e1ff60", null ],
    [ "open_print_sequence_addr", "structdpu__program__t.html#a71646d678b5c64ca347a2e8f2bf7b3c2", null ],
    [ "perfcounter_end_value_address", "structdpu__program__t.html#a997acf873f3db1033743601730d240d8", null ],
    [ "printf_buffer_address", "structdpu__program__t.html#aecd6de88c1a107f7b7baa2abae03f00b", null ],
    [ "printf_buffer_has_wrapped_address", "structdpu__program__t.html#adf06e926faee3dfd257594a9c9b024f1", null ],
    [ "printf_buffer_size", "structdpu__program__t.html#a01c55fb5188736274f3cc80442dba5a6", null ],
    [ "printf_write_pointer_address", "structdpu__program__t.html#ad7b224fee836ec38d81544317f80d28b", null ],
    [ "profiling_symbols", "structdpu__program__t.html#a64c746a77530797560f9211576e80e9a", null ],
    [ "program_path", "structdpu__program__t.html#a95a55540bd862d06bae61891ce2916e5", null ],
    [ "reference_count", "structdpu__program__t.html#a29bc576d6f86dee95917c27ab0044471", null ],
    [ "ret_mcount_address", "structdpu__program__t.html#acf38f3c37986702e3865d5e2dd214ced", null ],
    [ "symbols", "structdpu__program__t.html#a798ab0bb5a1678db2366c75f2857f3af", null ],
    [ "thread_profiling_address", "structdpu__program__t.html#a60b09615ccc6b349db273722fba69787", null ]
];