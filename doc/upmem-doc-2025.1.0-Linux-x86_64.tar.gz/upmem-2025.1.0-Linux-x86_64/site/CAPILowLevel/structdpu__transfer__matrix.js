var structdpu__transfer__matrix =
[
    [ "offset", "structdpu__transfer__matrix.html#a894bdfa2d603d8343f8ef01dda6fcd23", null ],
    [ "ptr", "structdpu__transfer__matrix.html#a286ea6b2dbf6e177d08aeec278f2a805", null ],
    [ "sg_ptr", "structdpu__transfer__matrix.html#a7f5ff12c65651f9a8d6bf574daca71d5", null ],
    [ "size", "structdpu__transfer__matrix.html#ab2c6b258f02add8fdf4cfc7c371dd772", null ],
    [ "type", "structdpu__transfer__matrix.html#ae9c38cbee3b489cf4fd22d1e5e48f1e1", null ]
];